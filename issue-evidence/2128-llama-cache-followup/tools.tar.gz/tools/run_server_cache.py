#!/usr/bin/env python3
"""Bounded localhost cache comparison. Parent owns GPU grant and service restore.

This script never touches an existing service and terminates only children it
spawns. Run --help/py_compile for CPU review; invoking normally runs a model.
"""
import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request


PROMPT = ("Write a short story of about 600 words about a lighthouse keeper who "
          "finds a message in a bottle. Use vivid but plain language. /no_think")
SAFE_ENV = ("PATH", "LD_LIBRARY_PATH", "CUDA_HOME", "CUDA_PATH", "CUDNN_PATH",
            "CUDA_VISIBLE_DEVICES", "CUDA_MODULE_LOADING", "MLX_PTX_CACHE_DIR")
HIT_METRIC = "mlxcel_prompt_cache_hits_total"
REUSE_METRIC = "mlxcel_prompt_cache_prefix_tokens_reused_total"
PAGED_METRICS = tuple('mlxcel_paged_decode_launches_total{path="' + p + '"}'
                      for p in ("fused_v2", "gather", "cascade"))


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def metrics_parse(text):
    result = {}
    for line in text.splitlines():
        fields = line.split()
        if len(fields) == 2 and fields[0].startswith(
                ("mlxcel_prompt_cache_", "mlxcel_paged_decode_launches_total")):
            try:
                result[fields[0]] = float(fields[1])
            except ValueError:
                pass
    return result


def response_summary(value):
    choice = value["choices"][0]
    message = choice["message"]
    output = {"content": message.get("content"),
              "reasoning_content": message.get("reasoning_content"),
              "tool_calls": message.get("tool_calls")}
    usage = value.get("usage", {})
    cached = usage.get("prompt_tokens_details", {}).get("cached_tokens")
    positions = (choice.get("logprobs") or {}).get("content") or []
    tokens = [{"token": p.get("token"), "bytes": p.get("bytes")}
              for p in positions]
    ids = [p["token_id"] for p in positions if "token_id" in p]
    return {
        "output_sha256": sha_bytes(canonical(output)), "output": output,
        "usage": usage, "usage_sha256": sha_bytes(canonical(usage)),
        "cached_tokens": cached, "finish_reason": choice.get("finish_reason"),
        "tokens": tokens, "tokens_sha256": sha_bytes(canonical(tokens)),
        "token_ids": ids if positions and len(ids) == len(positions) else None,
        "numeric_token_ids_exposed": bool(positions) and len(ids) == len(positions),
        "token_count_exposed": len(tokens),
        "top_two_gaps": [
            p["top_logprobs"][0]["logprob"] - p["top_logprobs"][1]["logprob"]
            if len(p.get("top_logprobs", [])) >= 2 else None
            for p in positions],
    }


def first_difference(a, b):
    left, right = a.get("tokens", []), b.get("tokens", [])
    if not left or not right:
        return {"token_index": None, "reason": "token trace unavailable"}
    index = next((i for i, (x, y) in enumerate(zip(left, right)) if x != y), None)
    if index is None and len(left) != len(right):
        index = min(len(left), len(right))
    def gap(s):
        v = s["top_two_gaps"]
        return v[index] if index is not None and index < len(v) else None
    return {"token_index": index, "reference_top_two_gap": gap(a),
            "candidate_top_two_gap": gap(b)}


class Experiment:
    def __init__(self, args):
        self.args = args
        self.root = Path(args.output).resolve()
        self.root.mkdir(parents=True, exist_ok=False)
        self.deadline = time.monotonic() + args.wall_timeout
        self.base = f"http://127.0.0.1:{args.port}"
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self.rows = []
        self.processes = []
        self.child = None
        self.process_dir = None
        self.env = dict(os.environ)
        kept = {k: self.env[k] for k in SAFE_ENV if k in self.env}
        removed = []
        for key in list(self.env):
            if key.startswith(("MLX_", "MLXCEL_", "APC_", "LLAMA_ARG_")):
                removed.append(key)
                self.env.pop(key)
        for key in ("LLAMA_API_KEY", "HF_TOKEN", "HUGGING_FACE_HUB_TOKEN",
                    "CUDA_LAUNCH_BLOCKING", "CUDA_FORCE_PTX_JIT", "CUDA_DISABLE_PTX_JIT",
                    "CUBLAS_WORKSPACE_CONFIG", "NVIDIA_TF32_OVERRIDE"):
            if key in self.env:
                removed.append(key)
            self.env.pop(key, None)
        self.env.update(kept)
        self.env.update({"MLXCEL_DEVICE": "gpu", "MLXCEL_APC_TRACE": "1",
                         "MLXCEL_SDPA_DETERMINISTIC": str(args.deterministic),
                         "MLXCEL_CACHE_DIR": str(self.root / "runtime-cache"),
                         "RUST_LOG": "info"})
        if args.graphs == "off":
            self.env["MLX_USE_CUDA_GRAPHS"] = "0"
        self.safe_env = {k: self.env[k] for k in set(SAFE_ENV) | {
            "MLXCEL_DEVICE", "MLXCEL_APC_TRACE", "MLXCEL_SDPA_DETERMINISTIC",
            "MLXCEL_CACHE_DIR", "MLX_USE_CUDA_GRAPHS", "RUST_LOG"} if k in self.env}
        self.payload = {"model": "cache-repro", "messages": [{"role": "user", "content": PROMPT}],
                        "max_tokens": args.max_tokens, "temperature": 0,
                        "seed": 0, "stream": False,
                        "user": "mlxcel-2128-cache-repro"}
        if args.logprobs:
            self.payload.update({"logprobs": True, "top_logprobs": 5})
        write_json(self.root / "manifest.json", {
            "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "binary": args.binary, "binary_sha256": file_sha(args.binary),
            "model_dir": args.model_dir, "options": vars(args),
            "harness_sha256": file_sha(__file__), "environment": self.safe_env,
            "removed_toggle_names": sorted(removed), "prompt": PROMPT,
            "prompt_sha256": sha_bytes(PROMPT.encode()), "payload": self.payload,
            "model_metadata_sha256": {p.name: file_sha(p) for p in
                Path(args.model_dir).iterdir() if p.is_file() and p.name in
                ("config.json", "tokenizer_config.json", "tokenizer.json", "generation_config.json")},
            "scope": "No service management; caller must own the GPU window."})

    def remaining(self, cap):
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("global wall timeout reached")
        return max(0.1, min(cap, remaining))

    def http(self, route, path, payload=None, timeout=None):
        request = urllib.request.Request(self.base + route,
            data=canonical(payload) if payload is not None else None,
            headers={"Content-Type": "application/json"},
            method="POST" if payload is not None else "GET")
        started = time.monotonic()
        try:
            with self.opener.open(request, timeout=self.remaining(timeout or self.args.request_timeout)) as response:
                status, raw = response.status, response.read()
        except urllib.error.HTTPError as exc:
            status, raw = exc.code, exc.read()
        path.write_bytes(raw)
        write_json(path.with_suffix(path.suffix + ".http.json"), {
            "route": route, "status": status, "seconds": time.monotonic() - started,
            "sha256": sha_bytes(raw)})
        if status != 200:
            raise RuntimeError(f"{route}: HTTP {status}, saved {path.name}")
        return raw

    def json_http(self, route, path, payload=None, timeout=None):
        return json.loads(self.http(route, path, payload, timeout))

    @contextlib.contextmanager
    def server(self, label, no_cache=False):
        directory = self.root / label
        directory.mkdir()
        self.process_dir = directory
        # Refuse to connect to or displace an existing listener.
        with socket.socket() as probe:
            # Match ordinary server restart semantics: a prior own connection
            # may remain in TIME_WAIT, but an active listener still prevents bind.
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            probe.bind(("127.0.0.1", self.args.port))
        argv = [self.args.binary, "-m", self.args.model_dir, "--alias", "cache-repro",
                "--host", "127.0.0.1", "--port", str(self.args.port),
                "--parallel", "4", "--metrics", "--no-warmup"]
        if no_cache:
            argv.append("--no-prompt-cache")
        if self.args.prefill_chunk_size is not None:
            argv += ["--prefill-chunk-size", str(self.args.prefill_chunk_size)]
        record = {"label": label, "argv": argv, "cwd": os.getcwd(),
                  "environment": self.safe_env, "no_cache": no_cache}
        self.processes.append(record)
        write_json(directory / "launch.json", record)
        with open(directory / "server.log", "wb") as log:
            child = subprocess.Popen(argv, env=self.env, stdout=log, stderr=subprocess.STDOUT)
            self.child = child
            record["pid"] = child.pid
            write_json(directory / "launch.json", record)
            try:
                ready_deadline = time.monotonic() + self.args.startup_timeout
                while True:
                    self.remaining(1)
                    if child.poll() is not None:
                        raise RuntimeError(f"server exited during readiness: {child.returncode}")
                    try:
                        self.json_http("/health", directory / "health.json", timeout=2)
                        models = self.json_http("/v1/models", directory / "models.json", timeout=3)
                        if not any(m.get("id") == "cache-repro" for m in models.get("data", [])):
                            raise RuntimeError("/v1/models lacks our explicit alias")
                        break
                    except (urllib.error.URLError, OSError, ValueError, RuntimeError):
                        if time.monotonic() >= ready_deadline:
                            raise TimeoutError("server readiness deadline exceeded")
                        time.sleep(0.3)
                self.json_http("/props", directory / "props.json", timeout=5)
                self.capture_runtime(directory, "ready")
                yield label
            finally:
                # Popen owns this exact child; never kill by name, port, or service.
                if child.poll() is None:
                    child.terminate()
                    try:
                        child.wait(timeout=20)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait(timeout=10)
                record["returncode_after_stop"] = child.returncode
                record["stopped_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                write_json(directory / "launch.json", record)
                self.child = None

    def capture_runtime(self, directory, label):
        """Linux-only own-child mapping evidence, not a guessed library version."""
        result = {"pid": self.child.pid, "available": False}
        try:
            proc = Path(f"/proc/{self.child.pid}")
            raw = (proc / "maps").read_bytes()
            (directory / f"{label}-proc-maps.txt").write_bytes(raw)
            result.update({"available": True, "maps_sha256": sha_bytes(raw),
                           "executable": os.readlink(proc / "exe"),
                           "proc_stat": (proc / "stat").read_text(),
                           "runtime_mappings": [line for line in raw.decode().splitlines()
                              if any(k in line.lower() for k in
                                     ("libcuda", "libcudnn", "libcublas", "libnvrtc", "libmlx"))]})
        except (OSError, UnicodeError) as exc:
            result["error"] = f"{type(exc).__name__}: {exc}"
        write_json(directory / f"{label}-runtime.json", result)
        return result

    def snapshot(self, directory, label):
        stats = self.json_http("/v1/cache/stats", directory / f"{label}-stats.json")
        raw = self.http("/metrics", directory / f"{label}-metrics.txt")
        return {"stats": stats, "metrics": metrics_parse(raw.decode())}

    def reset(self, label):
        directory = self.process_dir / label
        directory.mkdir()
        self.json_http("/v1/cache/reset", directory / "reset.json", {})
        stats = self.json_http("/v1/cache/stats", directory / "stats.json")
        if stats.get("entries") != 0 or stats.get("snapshot_entries") != 0:
            raise RuntimeError("cache reset did not report empty stores")

    def generate(self, label, expected):
        directory = self.process_dir / label
        directory.mkdir()
        body = dict(self.payload)
        if expected == "request_disabled":
            body["cache_prompt"] = False
        write_json(directory / "request.json", body)
        before = self.snapshot(directory, "before")
        value = self.json_http("/v1/chat/completions", directory / "response.json", body)
        after = self.snapshot(directory, "after")
        runtime = self.capture_runtime(directory, "after")
        row = response_summary(value)
        row.update({"label": str(directory.relative_to(self.root)), "expected": expected,
                    "request_sha256": sha_bytes(canonical(body)), "problems": []})
        row["metric_deltas"] = {
            k: after["metrics"].get(k, 0) - before["metrics"].get(k, 0)
            for k in (HIT_METRIC, REUSE_METRIC)}
        row["stats_deltas"] = {k: after["stats"].get(k, 0) - before["stats"].get(k, 0)
                               for k in ("hits", "lookups", "inserts")}
        row["paged_launch_deltas"] = {
            k: after["metrics"].get(k, 0) - before["metrics"].get(k, 0)
            for k in PAGED_METRICS}
        row["logprobs_requested"] = self.args.logprobs
        row["trace_count_minus_completion_tokens"] = (
            row["token_count_exposed"] - row["usage"].get("completion_tokens", 0)
            if self.args.logprobs else None)
        row["runtime_maps_available"] = runtime["available"]
        cached = row["cached_tokens"]
        if not row["output"]["content"] and not row["output"]["reasoning_content"]:
            row["problems"].append("empty generated output")
        if not isinstance(row["usage"].get("completion_tokens"), int) or row["usage"]["completion_tokens"] < 1:
            row["problems"].append("missing/zero completion_tokens")
        if after["stats"].get("paged_block_size", 0) <= 0:
            row["problems"].append("paged pool not proven active")
        if sum(row["paged_launch_deltas"].values()) <= 0:
            row["problems"].append("actual request paged launches not proven by metric deltas")
        if not runtime["available"]:
            row["problems"].append("own process runtime maps unavailable")
        if self.args.logprobs and not row["tokens"]:
            row["problems"].append("requested logprob token trace missing")
        if expected == "warm":
            if not isinstance(cached, int) or cached <= 0:
                row["problems"].append("warm request did not prove positive cached_tokens")
            if row["metric_deltas"][HIT_METRIC] < 1 or row["metric_deltas"][REUSE_METRIC] <= 0:
                row["problems"].append("scheduler hit/reused counters did not advance")
        elif expected in ("cold", "request_disabled") and cached != 0:
            row["problems"].append("cold/per-request-disabled did not report cached_tokens=0")
        elif expected == "server_disabled":
            if after["stats"].get("enabled") is not False or cached not in (None, 0):
                row["problems"].append("server-wide cache disable not proven")
        if expected != "warm" and any(row["metric_deltas"].values()):
            row["problems"].append("unexpected cache adoption in non-warm arm")
        if expected in ("request_disabled", "server_disabled") and any(row["stats_deltas"].values()):
            row["problems"].append("disabled arm changed lookup/donation counters")
        row["valid"] = not row["problems"]
        self.rows.append(row)
        write_json(directory / "summary.json", row)
        self.save_summary(False)
        print(json.dumps({"request": row["label"], "cached": cached,
                          "valid": row["valid"], "output": row["output_sha256"]}), flush=True)

    def save_summary(self, completed, error=None):
        groups = {}
        for mode in ("cold", "warm", "request_disabled", "server_disabled"):
            rows = [r for r in self.rows if r["expected"] == mode]
            groups[mode] = {"count": len(rows), "valid_count": sum(r["valid"] for r in rows),
                            "distinct_outputs": len({r["output_sha256"] for r in rows}),
                            "hashes": sorted({r["output_sha256"] for r in rows})}
        reference = next((r for r in self.rows if r["expected"] == "cold"), None)
        comparisons = [] if reference is None else [{
            "reference": reference["label"], "candidate": r["label"],
            "same_output": r["output_sha256"] == reference["output_sha256"],
            **first_difference(reference, r)} for r in self.rows[1:]]
        valid = completed and all(r["valid"] for r in self.rows)
        distinct = {m: g["distinct_outputs"] for m, g in groups.items()}
        if not valid:
            result = "INCOMPLETE_OR_INVALID_EVIDENCE"
        elif any(n > 1 for n in distinct.values()):
            result = "WITHIN_ARM_VARIABILITY_OBSERVED"
        elif groups["warm"]["hashes"] != groups["cold"]["hashes"]:
            controls_match = all(groups[m]["hashes"] == groups["cold"]["hashes"]
                                 for m in ("request_disabled", "server_disabled"))
            result = "STABLE_CACHE_STATE_DIFFERENCE" if controls_match else "STABLE_PATH_DIFFERENCES_WITH_CONTROL_MISMATCH"
        elif any(groups[m]["hashes"] != groups["cold"]["hashes"]
                 for m in ("request_disabled", "server_disabled")):
            result = "NO_COLD_WARM_DIFFERENCE_BUT_DISABLED_CONTROL_DIFFERS"
        else:
            result = "NO_COLD_WARM_DIFFERENCE_OBSERVED_IN_THIS_SAMPLE"
        write_json(self.root / "summary.json", {"completed": completed, "valid": valid,
            "classification": result, "error": error, "groups": groups,
            "comparisons": comparisons, "requests": self.rows,
            "claim_limit": "Bounded observations; not a proof of determinism or root cause."})

    def run(self):
        with self.server("cache-on-1"):
            for cycle in range(1, self.args.cycles + 1):
                self.reset(f"reset-{cycle}")
                self.generate(f"cycle-{cycle}-cold", "cold")
                self.generate(f"cycle-{cycle}-warm-1", "warm")
                self.generate(f"cycle-{cycle}-warm-2", "warm")
            for i in range(3):
                self.generate(f"request-disabled-{i+1}", "request_disabled")
        with self.server("cache-on-fresh-restart"):
            self.generate("cold", "cold")
            self.generate("warm", "warm")
        with self.server("cache-disabled", no_cache=True):
            for i in range(3):
                self.generate(f"repeat-{i+1}", "server_disabled")
        self.save_summary(True)
        return 0 if all(r["valid"] for r in self.rows) else 2


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--binary", required=True)
    p.add_argument("--model-dir", required=True)
    p.add_argument("--output", required=True, help="new output directory, must not exist")
    p.add_argument("--port", type=int, default=18128)
    p.add_argument("--deterministic", choices=(0, 1), type=int, required=True)
    p.add_argument("--graphs", choices=("default", "off"), default="default")
    p.add_argument("--logprobs", action="store_true",
                   help="diagnostic only: turns off eligible decode lookahead/fused sampling")
    p.add_argument("--cycles", type=int, default=2)
    p.add_argument("--max-tokens", type=int, default=800)
    p.add_argument("--request-timeout", type=float, default=180)
    p.add_argument("--startup-timeout", type=float, default=180)
    p.add_argument("--wall-timeout", type=float, default=900)
    p.add_argument("--prefill-chunk-size", type=int)
    args = p.parse_args()
    args.binary = str(Path(args.binary).resolve(strict=True))
    args.model_dir = str(Path(args.model_dir).resolve(strict=True))
    if not Path(args.model_dir, "config.json").is_file():
        p.error("model-dir must be an existing local checkpoint; no downloads")
    if not 1 <= args.cycles <= 5 or not 1 <= args.max_tokens <= 800:
        p.error("cycles must be 1..5 and max-tokens 1..800")
    if min(args.wall_timeout, args.startup_timeout, args.request_timeout) <= 0:
        p.error("timeouts must be positive")
    experiment = Experiment(args)
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f"signal {signum}")
    signal.signal(signal.SIGTERM, interrupted)
    try:
        return experiment.run()
    except BaseException as exc:
        experiment.save_summary(False, f"{type(exc).__name__}: {exc}")
        print(f"INCOMPLETE: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
