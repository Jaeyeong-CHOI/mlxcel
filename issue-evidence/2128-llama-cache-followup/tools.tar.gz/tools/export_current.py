#!/usr/bin/env python3
"""CPU-only, allowlist public exporter and offline verifier for fresh evidence.

export --cli-root WINDOW/results --server SERVER_CASE --commit COMMIT --output NEW
verify NEW
Only main-matrix and main-cudnn-off-control are selected under --cli-root.
No network, subprocess, service management, model access, or GPU execution.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
import sys

PROMPT = ("Write a short story of about 600 words about a lighthouse keeper who "
          "finds a message in a bottle. Use vivid but plain language. /no_think")
ENV = {"MLXCEL_DEVICE", "MLXCEL_SDPA_DETERMINISTIC", "MLX_USE_CUDA_GRAPHS",
       "MLX_CUDA_USE_CUDNN_SDPA", "MLXCEL_PRINT_TOKEN_IDS", "MLXCEL_APC_TRACE",
       "CUDA_CACHE_DISABLE", "CUDA_MODULE_LOADING", "RUST_LOG"}
PATH_ENV = {"MLXCEL_CACHE_DIR", "MLX_PTX_CACHE_DIR", "CUDA_CACHE_PATH",
            "LD_LIBRARY_PATH", "CUDA_HOME", "CUDA_PATH", "CUDNN_PATH"}
METRICS = {"mlxcel_prompt_cache_hits_total", "mlxcel_prompt_cache_misses_total",
           "mlxcel_prompt_cache_prefix_tokens_reused_total"} | {
    'mlxcel_paged_decode_launches_total{path="' + p + '"}'
    for p in ("fused_v2", "gather", "cascade")}
STATS = {"enabled", "apc_enabled", "block_size", "entries", "snapshot_entries",
         "hits", "lookups", "inserts", "paged_block_size", "paged_blocks_live",
         "paged_blocks_allocated", "paged_blocks_free", "snapshot_hits",
         "snapshot_lookups", "snapshot_inserts"}
MODES = ("cold", "warm", "request_disabled", "server_disabled")
CAVEAT = ("Finite observations are not a proof of determinism, semantic correctness, "
          "or root cause. Cache-state/path differences are distinct from within-arm "
          "variability. Token strings/bytes in server logprobs are not necessarily "
          "numeric token IDs. Logprob requests can alter decode scheduling. "
          "Library filename suffixes are evidence of loaded filenames, not an "
          "independently queried full runtime version. No service snapshots, raw "
          "process maps, raw logs, private environment, paths or weights are included.")


def need(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    need(path.is_file() and not path.is_symlink(), "Missing or symlinked input file")
    return json.loads(path.read_text())


def put(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def safe_name(name):
    need(isinstance(name, str) and re.fullmatch(r"[A-Za-z0-9_.-]+", name)
         and name not in (".", ".."), "Unsafe label")
    return name


def safe_rel(root, value):
    p = Path(value)
    need(not p.is_absolute() and p.parts and all(x not in (".", "..") for x in p.parts),
         "Unsafe relative evidence path")
    for x in p.parts:
        safe_name(x)
    result = root / p
    need(not any(p.is_symlink() for p in [result, *result.parents] if p != root.parent),
         "Symlink evidence path refused")
    return result


def environment(value):
    out = {}
    for k in sorted(ENV & value.keys()):
        v = value[k]
        need(isinstance(v, str) and re.fullmatch(r"[A-Za-z0-9_,.=+-]{1,40}", v),
             "Unexpected allowlisted environment value")
        out[k] = v
    return {"settings": out, "path_variable_names_present": sorted(PATH_ENV & value.keys()),
            "unlisted_values_omitted": True}


def libraries(paths):
    result = {}
    for entry in paths:
        # Works for either raw path strings or complete /proc/maps records.
        name = Path(entry.split()[-1]).name
        if re.fullmatch(r"lib(?:cuda|cudnn|cublas|nvrtc|mlx)[A-Za-z0-9_.+-]*\.so(?:\.[0-9.]+)?", name):
            version = name.partition(".so.")[2] or None
            result[name] = {"filename": name, "filename_version_suffix": version}
    return list(result.values())


def digest(value):
    need(isinstance(value, str) and re.fullmatch(r"[a-f0-9]{64}", value), "Bad digest")
    return value


def ids(path):
    value = load(path)
    need(isinstance(value, list) and value and all(type(n) is int and 0 <= n < 2**31 for n in value),
         "Invalid numeric token IDs")
    return value


def cli_group(source, target, allow_partial):
    manifest, summaries = load(source / "manifest.json"), load(source / "summary.json")
    need(manifest.get("prompt") == PROMPT and manifest.get("prompt_sha256") == sha(PROMPT.encode()),
         "CLI prompt is not the public fixture")
    need(not manifest.get("dry_run") and manifest.get("capture_token_ids") is True, "CLI is dry-run or lacks IDs")
    binary_sha = digest(manifest["binary_sha256"])
    models = {safe_name(Path(m["path"]).name): digest(m["config_sha256"]) for m in manifest["models"]}
    variants = [safe_name(v) for v in manifest["variants"]]
    repeats = manifest["repeats"]
    need(type(repeats) is int and repeats > 0, "Invalid repeat count")
    expected_keys = {m + "/" + v for m in models for v in variants}
    complete = set(summaries) == expected_keys
    groups = []
    for model in models:
        for variant in variants:
            label = model + "/" + variant
            original = summaries.get(label, {})
            rows = []
            for number in range(1, repeats + 1):
                rel = label + f"/run-{number:02d}"
                src, dst = safe_rel(source, rel), safe_rel(target, rel)
                if not (src / "result.json").is_file():
                    complete = False
                    continue
                result = load(src / "result.json")
                if result.get("valid") is not True or result.get("status") != "VALID":
                    complete = False
                    continue
                command = load(src / "command.json")
                argv = command["argv"]
                need(command.get("dry_run") is False and result.get("returncode") == 0, "Invalid CLI command")
                need(argv == [manifest["binary"], "generate", "-m", str(Path(manifest["models"][0]["path"]).parent / model),
                              "-p", PROMPT, "-n", str(manifest["max_tokens"]), "--temp", "0"],
                     "Unexpected CLI argv; refuse lossy command reconstruction")
                text = (src / "generated.txt").read_bytes()
                need(not (src / "generated.txt").is_symlink(), "Symlinked generated output refused")
                need(text.strip() and sha(text) == result["sha256"], "CLI output digest mismatch")
                prompt_ids, token_ids = ids(src / "prompt-ids.json"), ids(src / "token-ids.json")
                for kind, values in (("prompt", prompt_ids), ("token", token_ids)):
                    need(sha((src / (kind + "-ids.json")).read_bytes()) == result[kind + "_ids_sha256"]
                         and len(values) == result[kind + "_ids_count"], "CLI ID evidence mismatch")
                need(len(token_ids) == result["generated_tokens"], "CLI token count mismatch")
                need(len(text) == result["bytes"], "CLI output byte count mismatch")
                loaded = load(src / "loaded-runtime-libraries.json")
                runtime = libraries(loaded["libraries"])
                need(runtime or allow_partial, "No actual loaded runtime library evidence")
                complete &= bool(runtime)
                dst.mkdir(parents=True, exist_ok=False)
                (dst / "generated.txt").write_bytes(text)
                for kind, values in (("prompt", prompt_ids), ("token", token_ids)):
                    put(dst / (kind + "-ids.json"), values)
                public_argv = ["<MLXCEL_BINARY>", "generate", "-m", "<MODEL_DIR>/" + model,
                               "-p", PROMPT, "-n", str(manifest["max_tokens"]), "--temp", "0"]
                row = {"label": rel, "valid": True, "returncode": 0, "argv": public_argv,
                       "binary_sha256": binary_sha, "config_sha256": models[model],
                       "environment": environment(command["environment"]), "libraries": runtime,
                       "generated_tokens": len(token_ids), "prompt_tokens": len(prompt_ids),
                       "output_sha256": sha(text), "prompt_ids_sha256": sha(canonical(prompt_ids)),
                       "token_ids_sha256": sha(canonical(token_ids)),
                       "source_generated_sha256": digest(result["sha256"]),
                       "source_prompt_ids_file_sha256": digest(result["prompt_ids_sha256"]),
                       "source_token_ids_file_sha256": digest(result["token_ids_sha256"])}
                put(dst / "metadata.json", row)
                rows.append(row)
            hashes = sorted({r["output_sha256"] for r in rows})
            token_hashes = sorted({r["token_ids_sha256"] for r in rows})
            prompt_hashes = sorted({r["prompt_ids_sha256"] for r in rows})
            done = len(rows) == repeats
            complete &= done and original.get("status") in ("PASS", "DIVERGED")
            if done:
                need(original.get("expected_runs") == repeats == original.get("valid_runs")
                     == original.get("attempted_runs"), "CLI summary counts do not match raw records")
                need(original.get("hashes") == hashes and original.get("distinct_outputs") == len(hashes),
                     "CLI summary output hashes disagree")
                need(len(prompt_hashes) == 1 and original.get("distinct_prompt_sequences") == 1
                     and original.get("distinct_token_sequences") == len(token_hashes), "CLI token summary disagrees")
                if "token_ids_hashes" in original:
                    need(original["token_ids_hashes"] == sorted({r["source_token_ids_file_sha256"] for r in rows})
                         and original["prompt_ids_hashes"] == sorted({r["source_prompt_ids_file_sha256"] for r in rows}),
                         "CLI summary source token-file hashes disagree")
                status = "PASS" if len(hashes) == len(token_hashes) == 1 else "DIVERGED"
                need(original["status"] == status, "CLI classification disagrees")
            groups.append({"label": label, "expected": repeats, "exported_valid": len(rows),
                           "complete": done, "distinct_outputs": len(hashes),
                           "distinct_token_sequences": len(token_hashes), "distinct_prompt_sequences": len(prompt_hashes),
                           "output_hashes": hashes, "token_hashes": token_hashes,
                           "run_labels": [r["label"] for r in rows]})
    need(complete or allow_partial, "Incomplete/invalid CLI summary: use --allow-partial only deliberately")
    report = {"type": "cli", "complete": complete, "binary_sha256": binary_sha, "groups": groups}
    put(target / "summary.json", report)
    (target / "prompt.txt").write_text(PROMPT)
    return report


def metric_values(path):
    result = {}
    for line in path.read_text().splitlines():
        fields = line.split()
        if len(fields) == 2 and fields[0] in METRICS:
            n = float(fields[1])
            need(math.isfinite(n), "Nonfinite metric")
            result[fields[0]] = n
    return result


def numeric_tree(value):
    if isinstance(value, dict):
        return {k: numeric_tree(v) for k, v in value.items() if re.fullmatch(r"[a-z_]+", k)}
    need(value is None or type(value) in (int, float, bool), "Unexpected nonnumeric usage/stat field")
    return value


def public_request(value):
    allowed = {"model", "messages", "max_tokens", "temperature", "seed", "stream", "user",
               "logprobs", "top_logprobs", "cache_prompt"}
    need(set(value) <= allowed and value.get("messages") == [{"role": "user", "content": PROMPT}]
         and value.get("model") == "cache-repro" and value.get("user") == "mlxcel-2128-cache-repro"
         and value.get("temperature") == 0 and value.get("seed") == 0 and value.get("stream") is False,
         "Server payload not the pinned public fixture")
    return value


def server_case(source, target, allow_partial):
    manifest, original = load(source / "manifest.json"), load(source / "summary.json")
    need(manifest.get("prompt") == PROMPT and manifest.get("prompt_sha256") == sha(PROMPT.encode()),
         "Server prompt mismatch")
    public_request(manifest["payload"])
    complete = original.get("completed") is True and original.get("valid") is True
    rows, launches = [], {}
    for old in original.get("requests", []):
        if old.get("valid") is not True:
            complete = False
            continue
        label = old["label"]
        src, dst = safe_rel(source, label), safe_rel(target, label)
        request = public_request(load(src / "request.json"))
        need(sha(canonical(request)) == old["request_sha256"], "Server request digest mismatch")
        response = load(src / "response.json")
        choice = response["choices"][0]
        message = choice["message"]
        output = {k: message.get(k) for k in ("content", "reasoning_content", "tool_calls")}
        need(output["tool_calls"] in (None, []), "Unexpected tool calls in plain public fixture")
        need(sha(canonical(output)) == old["output_sha256"] and output == old["output"],
             "Server output does not match raw response")
        usage = numeric_tree(response.get("usage", {}))
        need(usage == old["usage"] and usage.get("completion_tokens", 0) > 0, "Server usage mismatch")
        http = load(src / "response.json.http.json")
        need(http["status"] == 200 and http["sha256"] == sha((src / "response.json").read_bytes()),
             "Server HTTP receipt mismatch")
        metrics, stats = {}, {}
        for phase in ("before", "after"):
            metrics[phase] = metric_values(src / (phase + "-metrics.txt"))
            raw_stats = load(src / (phase + "-stats.json"))
            stats[phase] = {k: numeric_tree(v) for k, v in raw_stats.items() if k in STATS}
        delta = {k: metrics["after"].get(k, 0) - metrics["before"].get(k, 0) for k in METRICS}
        for k, v in {**old["metric_deltas"], **old["paged_launch_deltas"]}.items():
            need(k in METRICS and delta[k] == v, "Server metric delta mismatch")
        need(sum(v for k, v in delta.items() if k.startswith("mlxcel_paged_decode")) > 0
             and stats["after"].get("paged_block_size", 0) > 0, "Paged path not evidenced")
        for k, v in old["stats_deltas"].items():
            need(k in STATS and stats["after"].get(k, 0) - stats["before"].get(k, 0) == v,
                 "Server stat delta mismatch")
        mode = old["expected"]
        need(mode in MODES, "Unknown server arm")
        cached = usage.get("prompt_tokens_details", {}).get("cached_tokens")
        hit, reused = delta["mlxcel_prompt_cache_hits_total"], delta["mlxcel_prompt_cache_prefix_tokens_reused_total"]
        if mode == "warm":
            need(type(cached) is int and cached > 0 and hit >= 1 and reused > 0, "Warm hit not evidenced")
        else:
            need(hit == reused == 0, "Unexpected cache adoption")
            need(cached == 0 if mode != "server_disabled" else cached in (None, 0), "Non-warm cached tokens")
        if mode == "server_disabled":
            need(stats["after"].get("enabled") is False, "Server disable not evidenced")
        if mode in ("request_disabled", "server_disabled"):
            need(all(v == 0 for v in old["stats_deltas"].values()), "Disabled lookup/donation changed")
        need((request.get("cache_prompt") is False) == (mode == "request_disabled"), "Per-request opt-out mismatch")
        runtime = load(src / "after-runtime.json")
        need(runtime.get("available") is True, "No actual server runtime maps")
        loaded = libraries(runtime.get("runtime_mappings", []))
        need(loaded, "Loaded library names unavailable")
        process = label.split("/")[0]
        if process not in launches:
            launch = load(source / process / "launch.json")
            argv = launch["argv"]
            expected = [manifest["binary"], "-m", manifest["model_dir"], "--alias", "cache-repro",
                        "--host", "127.0.0.1", "--port", str(manifest["options"]["port"]),
                        "--parallel", "4", "--metrics", "--no-warmup"]
            if launch["no_cache"]:
                expected.append("--no-prompt-cache")
            chunk = manifest["options"].get("prefill_chunk_size")
            if chunk is not None:
                expected += ["--prefill-chunk-size", str(chunk)]
            need(argv == expected, "Server argv differs from planned fixture")
            argv = ["<MLXCEL_SERVER>", "-m", "<MODEL_DIR>"] + argv[3:]
            argv[argv.index("--host") + 1] = "<LOOPBACK>"
            argv[argv.index("--port") + 1] = "<PORT>"
            launches[process] = {"argv": argv, "no_cache": launch["no_cache"],
                                 "environment": environment(launch["environment"])}
        row = {"label": label, "expected": mode, "valid": True, "output_sha256": old["output_sha256"],
               "request_sha256": old["request_sha256"], "usage": usage,
               "finish_reason": choice.get("finish_reason"), "cached_tokens": cached,
               "metric_deltas": delta, "stats_deltas": old["stats_deltas"], "libraries": loaded,
               "logprobs_requested": request.get("logprobs", False)}
        dst.mkdir(parents=True, exist_ok=False)
        put(dst / "request.json", request)
        put(dst / "output.json", output)
        put(dst / "metadata.json", row)
        put(dst / "metrics.json", metrics)
        put(dst / "stats.json", stats)
        if request.get("logprobs"):
            positions = (choice.get("logprobs") or {}).get("content") or []
            need(positions, "Missing requested token trace")
            # Only documented token evidence; no arbitrary response extensions.
            fields = {"token", "bytes", "logprob", "token_id"}
            trace = [{**{k: v for k, v in p.items() if k in fields},
                      "top_logprobs": [{k: v for k, v in q.items() if k in fields}
                                       for q in p.get("top_logprobs", [])]} for p in positions]
            put(dst / "logprobs.json", trace)
        rows.append(row)
    counts = Counter(r["expected"] for r in rows)
    cycles = manifest["options"]["cycles"]
    wanted = {"cold": cycles + 1, "warm": 2 * cycles + 1, "request_disabled": 3, "server_disabled": 3}
    complete &= dict(counts) == wanted
    groups = {}
    for mode in MODES:
        matching = [r for r in rows if r["expected"] == mode]
        hashes = sorted({r["output_sha256"] for r in matching})
        groups[mode] = {"count": len(matching), "distinct_outputs": len(hashes), "hashes": hashes}
        old_group = original.get("groups", {}).get(mode, {})
        if complete:
            need(old_group.get("hashes") == hashes and old_group.get("count") == len(matching)
                 == old_group.get("valid_count"), "Server group summary differs from raw records")
    need(complete or allow_partial, "Incomplete/invalid server summary: explicit --allow-partial required")
    if not complete:
        classification = "INCOMPLETE_OR_INVALID_EVIDENCE"
    elif any(g["distinct_outputs"] > 1 for g in groups.values()):
        classification = "WITHIN_ARM_VARIABILITY_OBSERVED"
    elif groups["warm"]["hashes"] != groups["cold"]["hashes"]:
        classification = ("STABLE_CACHE_STATE_DIFFERENCE" if all(groups[m]["hashes"] == groups["cold"]["hashes"]
                          for m in ("request_disabled", "server_disabled")) else "STABLE_PATH_DIFFERENCES_WITH_CONTROL_MISMATCH")
    elif any(groups[m]["hashes"] != groups["cold"]["hashes"] for m in ("request_disabled", "server_disabled")):
        classification = "NO_COLD_WARM_DIFFERENCE_BUT_DISABLED_CONTROL_DIFFERS"
    else:
        classification = "NO_COLD_WARM_DIFFERENCE_OBSERVED_IN_THIS_SAMPLE"
    if complete:
        need(original["classification"] == classification, "Server classification mismatch")
    report = {"type": "server", "complete": complete, "classification": classification,
              "binary_sha256": digest(manifest["binary_sha256"]),
              "model_directory_name": safe_name(Path(manifest["model_dir"]).name),
              "model_metadata_sha256": {safe_name(k): digest(v) for k, v in manifest["model_metadata_sha256"].items()},
              "environment": environment(manifest["environment"]), "launches": launches,
              "groups": groups, "expected_counts": wanted, "requests": rows}
    put(target / "summary.json", report)
    return report


def verify(root):
    receipt = load(root / "manifest.json")
    expected = {}
    for line in (root / "SHA256SUMS").read_text().splitlines():
        checksum, rel = line.split("  ", 1)
        path = safe_rel(root, rel)
        need(rel not in expected and sha(path.read_bytes()) == digest(checksum), "Checksum mismatch")
        expected[rel] = checksum
    actual = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file() and p.name != "SHA256SUMS"}
    need(actual == set(expected), "Unexpected/missing public files")
    checked = 0
    for item in receipt["datasets"]:
        base = safe_rel(root, item["path"])
        report = load(base / "summary.json")
        if report["type"] == "cli":
            for group in report["groups"]:
                outputs, token_sets, prompt_sets = [], [], []
                for label in group["run_labels"]:
                    run = safe_rel(base, label)
                    meta = load(run / "metadata.json")
                    outputs.append(sha((run / "generated.txt").read_bytes()))
                    tokens, prompt = ids(run / "token-ids.json"), ids(run / "prompt-ids.json")
                    token_sets.append(sha(canonical(tokens)))
                    prompt_sets.append(sha(canonical(prompt)))
                    need(outputs[-1] == meta["output_sha256"] and token_sets[-1] == meta["token_ids_sha256"]
                         and prompt_sets[-1] == meta["prompt_ids_sha256"] and len(tokens) == meta["generated_tokens"]
                         and len(prompt) == meta["prompt_tokens"], "Public CLI metadata mismatch")
                    checked += 1
                need(sorted(set(outputs)) == group["output_hashes"] and sorted(set(token_sets)) == group["token_hashes"]
                     and len(outputs) == group["exported_valid"] and len(set(prompt_sets)) == group["distinct_prompt_sequences"],
                     "Public CLI group mismatch")
        else:
            for row in report["requests"]:
                run = safe_rel(base, row["label"])
                need(sha(canonical(load(run / "output.json"))) == row["output_sha256"]
                     and sha(canonical(public_request(load(run / "request.json")))) == row["request_sha256"],
                     "Public server output/request mismatch")
                metrics = load(run / "metrics.json")
                need(all(metrics["after"].get(k, 0) - metrics["before"].get(k, 0) == v
                         for k, v in row["metric_deltas"].items()), "Public metrics mismatch")
                checked += 1
            for mode, group in report["groups"].items():
                matching = [r for r in report["requests"] if r["expected"] == mode]
                need(group["count"] == len(matching) and group["hashes"] == sorted({r["output_sha256"] for r in matching}),
                     "Public server group mismatch")
    return {"verified_files": len(expected), "verified_runs_requests": checked,
            "partial": receipt["partial"], "claim_limit": CAVEAT}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="action", required=True)
    export = subs.add_parser("export")
    export.add_argument("--cli-root", type=Path)
    export.add_argument("--server", type=Path, action="append", default=[])
    export.add_argument("--output", type=Path, required=True)
    export.add_argument("--commit", required=True)
    export.add_argument("--allow-partial", action="store_true")
    check = subs.add_parser("verify")
    check.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.action == "verify":
        print(json.dumps(verify(args.output), indent=2))
        return
    need(args.cli_root or args.server, "At least one evidence source required")
    need(re.fullmatch(r"[a-f0-9]{40}", args.commit), "Immutable full commit required")
    need(not args.output.exists(), "Output must be a new directory")
    args.output.mkdir(parents=True)
    datasets, partial, cli_runs = [], False, 0
    if args.cli_root:
        for name in ("main-matrix", "main-cudnn-off-control"):
            source = args.cli_root / name
            if not source.is_dir() and args.allow_partial:
                partial = True
                continue
            rel = "cli/" + name
            report = cli_group(source, args.output / rel, args.allow_partial)
            intended = (["det-off", "det-off-graphs-off", "det-on", "det-on-graphs-off"]
                        if name == "main-matrix" else ["cudnn-off-graphs-off"])
            grid_matches = ({g["label"] for g in report["groups"]} ==
                            {"Llama-3.2-1B-Instruct-4bit/" + v for v in intended}
                            and all(g["expected"] == 5 for g in report["groups"]))
            need(grid_matches or args.allow_partial, "CLI grid is not the fixed current-main 25-run experiment")
            partial |= not grid_matches
            partial |= not report["complete"]
            cli_runs += sum(g["exported_valid"] for g in report["groups"])
            datasets.append({"path": rel, "type": "cli", "complete": report["complete"]})
        need(cli_runs == 25 or args.allow_partial, "Expected fixed 25-run current CLI matrix")
        partial |= cli_runs != 25
    for i, source in enumerate(args.server, 1):
        rel = f"server/case-{i:02d}"
        report = server_case(source, args.output / rel, args.allow_partial)
        partial |= not report["complete"]
        datasets.append({"path": rel, "type": "server", "complete": report["complete"]})
    need(datasets, "No exportable datasets")
    put(args.output / "manifest.json", {"schema": 1, "source_commit": args.commit,
        "partial": bool(partial), "allow_partial_requested": args.allow_partial,
        "datasets": datasets, "claim_limit": CAVEAT,
        "source_scope": "Only selected fresh evidence; no historical runs merged into counts."})
    (args.output / "README.md").write_text("# Sanitized fresh reproduction evidence\n\n" + CAVEAT +
        "\n\nPartial: " + str(bool(partial)) +
        ". A partial bundle excludes invalid/missing requests; never report its selected subset as a completed planned matrix.\n" +
        "\nOutput comparisons exclude response IDs and timestamps. Runtime path variables are named but their values are omitted. " +
        "Raw service/environment files and logs are deliberately absent. Public metadata uses command path placeholders.\n" +
        "\nCLI PASS means one observed output/token sequence in the finite sample only. Server logprobs, if present, " +
        "are a separately observable scheduling condition. No throughput claim is made.\n" +
        "\nVerify offline: `python3 export_current.py verify BUNDLE_DIR` (use the exporter supplied alongside this bundle).\n")
    files = sorted(p for p in args.output.rglob("*") if p.is_file())
    (args.output / "SHA256SUMS").write_text("".join(sha(p.read_bytes()) + "  " + str(p.relative_to(args.output)) + "\n" for p in files))
    print(json.dumps(verify(args.output), indent=2))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError, json.JSONDecodeError) as exc:
        # Deliberately no source values/paths in publication-oriented diagnostics.
        print("REFUSED: evidence validation failed (" + type(exc).__name__ + "). " +
              (str(exc) if type(exc) is ValueError else "Inspect local inputs privately."), file=sys.stderr)
        raise SystemExit(2)
