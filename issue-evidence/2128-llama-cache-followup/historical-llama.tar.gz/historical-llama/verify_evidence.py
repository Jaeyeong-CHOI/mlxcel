#!/usr/bin/env python3
"""Verify the historical five-run public Llama witness using only Python's stdlib.

Usage: python3 verify_evidence.py /path/to/historical-llama
Checks all SHA256SUMS entries, complete coverage, metadata, identical prompt IDs,
generated-token counts and the original A/B branch. Never executes mlxcel.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('evidence', nargs='?', type=Path, default=Path(__file__).resolve().parent)
    args = ap.parse_args()
    root = args.evidence.resolve()
    listed = set()
    for line in (root / 'SHA256SUMS').read_text().splitlines():
        expected, name = line.split(maxsplit=1)
        name = name.lstrip('*')
        path = (root / name).resolve()
        assert path.is_relative_to(root), 'Unsafe checksum path'
        assert name not in listed, 'Duplicate checksum entry'
        assert digest(path) == expected, f'Hash mismatch: {name}'
        listed.add(name)
    files = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'}
    assert listed == files, 'SHA256SUMS does not cover exactly all files'
    summary = json.loads((root / 'summary.json').read_text())
    assert summary['source_commit'] == 'd253154c0e6ec8ce8056d69153543ca3993c5314'
    assert summary['model_revision'] == '08231374eeacb049a0eade7922910865b8fce912'
    assert digest(root / 'prompt.txt') == summary['prompt_text_sha256']
    assert not (root / 'prompt.txt').read_bytes().endswith(b'\n')
    arrays, prompts, texts = [], [], []
    token_counts, text_counts = Counter(), Counter()
    runs = sorted(root.glob('run-*'))
    assert len(runs) == 5
    for run in runs:
        meta = json.loads((run / 'metadata.json').read_text())
        command = json.loads((run / 'command.json').read_text())
        assert meta['recorded_returncode'] == 0
        assert meta['stdout_runtime'] == 'NVIDIA GPU (CUDA)'
        env = command['computation_environment']
        assert env == {'MLXCEL_DEVICE': 'gpu', 'MLXCEL_PRINT_TOKEN_IDS': '1', 'MLX_USE_CUDA_GRAPHS': '0'}
        prompt = command['argv'][command['argv'].index('-p') + 1]
        assert prompt.encode() == (root / 'prompt.txt').read_bytes()
        for filename, expected in meta['sha256'].items():
            assert digest(run / filename) == expected
        tids = json.loads((run / 'token-ids.json').read_text())
        pids = json.loads((run / 'prompt-ids.json').read_text())
        text = (run / 'generated.txt').read_text()
        assert len(tids) == meta['generated_ids_count'] == 800
        assert len(pids) == meta['prompt_ids_count'] == 67
        arrays.append(tids)
        prompts.append(pids)
        texts.append(text)
        token_counts[digest(run / 'token-ids.json')] += 1
        text_counts[digest(run / 'generated.txt')] += 1
    assert all(p == prompts[0] for p in prompts)
    assert all(t == arrays[1] for t in arrays[1:])
    assert dict(token_counts) == summary['token_sequence_counts']
    first = next(i for i, (a, b) in enumerate(zip(arrays[1], arrays[0])) if a != b)
    assert (first, arrays[1][first], arrays[0][first]) == (251, 95749, 9235)
    first_text = next(i for i, (a, b) in enumerate(zip(texts[1], texts[0])) if a != b)
    assert first_text == 1130
    print(json.dumps({'status': 'PASS', 'sha256_entries': len(listed), 'runs': 5,
        'distinct_token_arrays': len(token_counts), 'distinct_texts': len(text_counts),
        'identical_prompt_arrays': True, 'first_different_token_index_zero_based': first,
        'preceding_context_tokens': len(prompts[0]) + first,
        'sampling': 'Adaptive block of five, maximum 50; stopped after first five. Not a population-rate estimate.'}, indent=2))


if __name__ == '__main__':
    main()
