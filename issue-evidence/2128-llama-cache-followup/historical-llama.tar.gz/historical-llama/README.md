# Historical Llama fresh-process nondeterminism witness

This small evidence set documents five **historical, successful CUDA CLI executions on 2026-10-06** of the original unmodified mlxcel executable. It is **not a test of current main or PR #2162**, and does not establish a Llama kernel-level root cause or a server prompt-cache problem.

## Configuration

- mlxcel commit: `d253154c0e6ec8ce8056d69153543ca3993c5314`.
- Frozen CLI SHA256: `74761296c12814e42728a74c09c92cf38031482c9a13a1e61c17bcb74583bd9e`.
- Linked MLX source commit: `81ba1c6a0e50a9268b931579c2d4f1158b9aab5a`.
- Model: `mlx-community/Llama-3.2-1B-Instruct-4bit`, revision `08231374eeacb049a0eade7922910865b8fce912`. Individual checkpoint/tokenizer hashes are in `model-manifest.json`; weights are not included.
- NVIDIA GB10, compute capability 12.1 (`sm_121` native cubin), NVIDIA driver 580.178.04, CUDA 13.0, cuDNN 9.13.0, Linux aarch64.
- Runtime versions were recovered from contemporaneous environment/runtime provenance. **Per-Llama-process loaded-library maps were not captured** in these historical runs.
- CLI stdout recorded `KV cache mode: fp16 (applied to 16 of 16 layers)`.
- Temperature 0, cap 800 tokens, outer MLX CUDA graphs disabled, cuDNN SDPA at its enabled default. All five runs generated 800 tokens and exited successfully.

## Exact prompt and portable invocation

`prompt.txt` contains the exact prompt bytes with **no trailing newline**:

```text
Write a short story of about 600 words about a lighthouse keeper who finds a message in a bottle. Use vivid but plain language. /no_think
```

After configuring the appropriate CUDA/cuDNN library paths, repeat this command as fresh CLI processes with the pinned model:

```sh
env MLXCEL_DEVICE=gpu MLXCEL_PRINT_TOKEN_IDS=1 MLX_USE_CUDA_GRAPHS=0 \
  /path/to/mlxcel generate \
  -m /path/to/Llama-3.2-1B-Instruct-4bit \
  -p 'Write a short story of about 600 words about a lighthouse keeper who finds a message in a bottle. Use vivid but plain language. /no_think' \
  -n 800 --temp 0
```

Remove inherited experimental `MLX_*`, `MLXCEL_*`, and `LLAMA_ARG_*` overrides before setting the flags above, except intentional PTX/CCCL cache paths. The original harness also removed `CUDA_LAUNCH_BLOCKING`, `CUDA_FORCE_PTX_JIT`, `CUDA_DISABLE_PTX_JIT`, `CUBLAS_WORKSPACE_CONFIG`, and `NVIDIA_TF32_OVERRIDE`. `MLX_CUDA_USE_CUDNN_SDPA` was unset in these runs.

The original harness used a group-specific application cache directory and a shared PTX cache. **Fresh process does not mean a cold compiler cache.** No server was queried by these trials. The actual 67 prompt IDs include the model's chat template/system prefix; compare the included arrays when matching another version, not just the user-visible string.

## Observed result

The five runs contain **two distinct complete text/token outputs**:

- `run-01`: alternate B, once.
- `run-02`–`run-05`: baseline A, four times.
- First different generated-token index: **251, zero-based**; this is generated token ordinal 252 with **318 preceding context tokens** (67 prompt + 251 preceding generated tokens).
- A selects token **95749**; B selects **9235**.
- First displayed-character difference: **1130, zero-based**.

The corresponding text branches are:

```text
A: The cork was old and brittle, and it came off with a loud crack.
B: The cork was old and dry, and the glass was cloudy with age.
```

Sequence A hashes:

- Generated text: `e7a6c083bfcaa4b51fea3eef1e2bd710d714ac378ab7c9453a94e864086d1658`.
- Token JSON: `a8f472d1b1cfcc1e2c82cb75f9dd753d270b4941784a0df434251f50db26d00d`.

Sequence B hashes:

- Generated text: `9dea243e428b0473c6c06a53b73512d70842b3ab7eb838d2d1327a66b48af744`.
- Token JSON: `2c3c57389c7eee77f85d5fadf9a3cd93c289a287c8096c7134cc7ce8bc95c5df`.

The original diagnostic used adaptive five-run blocks up to a maximum of 50, stopping once a second token sequence was observed. It stopped after these five new runs. **This is a positive reproduction witness, not an estimate of a 20% failure probability.** Earlier five-run samples had been stable.

## Files and validation

Each run directory contains:

- `generated.txt`, `prompt-ids.json`, `token-ids.json`: **byte-for-byte copies** of the original evidence files, including their original JSON serialization.
- `command.json`: a sanitized reconstruction of the original invocation; filesystem paths are placeholders and irrelevant inherited PATH entries are omitted.
- `metadata.json`: sanitized observations recomputed from historical stdout/stderr, recorded exit status, counts, and file hashes.

Raw logs are omitted because they include machine-specific model paths. Their successful CUDA header, complete displayed generation, token records, and exit status were independently rechecked before staging this bundle. The exact text and token files are retained without redaction. No private environment, service snapshots, addresses, weights, or executables are included.

`summary.json` contains the machine-readable identities and counts. `SHA256SUMS` covers every included file except itself. JSON-file hashes depend on serialization; compare parsed arrays if using a different JSON writer.

```sh
sha256sum -c SHA256SUMS
```

This bundle alone does not prove bit-identical logits, locate the first differing internal value, identify a cuDNN D64 defect, or show what current main does. Current-version results should be presented separately with their own binary/runtime identity and complete sample counts.
