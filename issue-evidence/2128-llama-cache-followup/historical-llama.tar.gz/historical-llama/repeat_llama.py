#!/usr/bin/env python3
"""Fixed-sample fresh-process Llama CLI repetition; no external Python dependencies.

This script executes GPU workloads only when explicitly invoked with --run.
Use a quiet GPU window and your existing CUDA/cuDNN installation. It does not
change services, source, installed libraries, model weights, or compiler caches.
The caller is responsible for GPU ownership. New output directories are required.
Raw logs are held in memory and are not published/saved; --save-private-raw saves
them locally and they must be reviewed/redacted before any public upload.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

PROMPT = ('Write a short story of about 600 words about a lighthouse keeper who '
          'finds a message in a bottle. Use vivid but plain language. /no_think')
KEEP_MLX = {'MLX_PTX_CACHE_DIR', 'MLX_CCCL_DIR'}
OTHER_OVERRIDES = {'CUDA_LAUNCH_BLOCKING', 'CUDA_FORCE_PTX_JIT', 'CUDA_DISABLE_PTX_JIT',
                   'CUBLAS_WORKSPACE_CONFIG', 'NVIDIA_TF32_OVERRIDE'}


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')


def parse(stdout, stderr):
    assert b'Runtime device: NVIDIA GPU (CUDA)' in stdout, 'CUDA device header absent'
    markers = list(re.finditer(rb'(?m)^Generating\.\.\.\r?\n', stdout))
    stats = list(re.finditer(rb'(?m)^\[Generated ([0-9]+) tokens in ([0-9.]+)s = ([0-9.]+) tok/s\]\r?$', stdout))
    assert len(markers) == len(stats) == 1, 'Missing or duplicate generation records'
    marker, stat = markers[0], stats[0]
    assert stat.start() > marker.end() and not stdout[stat.end():].strip(), 'Invalid generation footer'
    body = stdout[marker.end():stat.start()]
    assert body.startswith(PROMPT.encode()) and body.endswith(b'\n\n'), 'Prompt echo/separator mismatch'
    generated = body[len(PROMPT.encode()):-2]
    generated.decode('utf-8', errors='strict')
    assert generated.strip(), 'Empty generation'
    assert int(stat[1]) == 800, 'Run did not produce the requested 800 tokens'
    assert float(stat[2]) > 0 and float(stat[3]) > 0
    arrays = {}
    for kind in ['prompt', 'token']:
        prefix = ('[' + kind + ' ids').encode()
        lines = [line for line in stderr.splitlines() if line.startswith(prefix)]
        assert len(lines) == 1, 'Missing or duplicate token-ID record'
        match = re.fullmatch(rb'\[' + kind.encode() + rb' ids \(([0-9]+)\): ([0-9]+(?: [0-9]+)*)\]', lines[0])
        assert match, 'Malformed token-ID record'
        ids = list(map(int, match[2].split()))
        assert len(ids) == int(match[1])
        arrays[kind] = ids
    assert len(arrays['token']) == 800
    return generated, arrays


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--binary', type=Path, required=True)
    ap.add_argument('--model', type=Path, required=True)
    ap.add_argument('--evidence', type=Path, default=Path(__file__).resolve().parent,
                    help='Directory containing the published model-manifest.json and run-01/prompt-ids.json')
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--runs', type=int, default=20)
    ap.add_argument('--source-commit', help='Caller-supplied source identity, not inferred from binary')
    ap.add_argument('--graphs', choices=['off', 'default'], default='off')
    det_group = ap.add_mutually_exclusive_group()
    det_group.add_argument('--deterministic', action='store_true', help='Set MLXCEL_SDPA_DETERMINISTIC=1 (for versions that support it)')
    det_group.add_argument('--deterministic-off', action='store_true', help='Explicitly set MLXCEL_SDPA_DETERMINISTIC=0, as in the fresh positive witness')
    ap.add_argument('--cudnn-off', action='store_true', help='Set MLX_CUDA_USE_CUDNN_SDPA=0')
    ap.add_argument('--save-private-raw', action='store_true')
    ap.add_argument('--run', action='store_true', help='Actually execute. Without this flag only print the plan.')
    args = ap.parse_args()
    if not 1 <= args.runs <= 50:
        ap.error('--runs must be between 1 and 50')
    binary, model, evidence, out = [p.resolve() for p in [args.binary, args.model, args.evidence, args.out]]
    removed = sorted(k for k in os.environ if
        ((k.startswith(('MLX_', 'MLXCEL_', 'LLAMA_ARG_')) and k not in KEEP_MLX) or k in OTHER_OVERRIDES))
    env = {k: v for k, v in os.environ.items() if k not in removed}
    flags = {'MLXCEL_DEVICE': 'gpu', 'MLXCEL_PRINT_TOKEN_IDS': '1'}
    if args.graphs == 'off':
        flags['MLX_USE_CUDA_GRAPHS'] = '0'
    if args.deterministic:
        flags['MLXCEL_SDPA_DETERMINISTIC'] = '1'
    if args.deterministic_off:
        flags['MLXCEL_SDPA_DETERMINISTIC'] = '0'
    if args.cudnn_off:
        flags['MLX_CUDA_USE_CUDNN_SDPA'] = '0'
    manifest = {'sampling': 'Fixed sample; no early stop on valid divergence', 'requested_runs': args.runs,
        'computation_environment': flags, 'removed_environment_names': removed,
        'source_commit_caller_supplied': args.source_commit, 'actual_execution': args.run,
        'argv': ['<MLXCEL_BINARY>', 'generate', '-m', '<PINNED_MODEL_DIRECTORY>', '-p', PROMPT, '-n', '800', '--temp', '0'],
        'compiler_cache_policy': 'Fresh CLI processes, shared compiler/PTX caches; not per-run cold caches',
        'library_provenance': 'Inherited configured CUDA/cuDNN paths; this script does not identify loaded cuDNN version',
        'private_raw_saved': args.save_private_raw}
    if not args.run:
        print(json.dumps(manifest, indent=2))
        return 0
    if out.exists():
        ap.error('--out must not exist (prevents overwriting evidence)')
    expected_model = json.loads((evidence / 'model-manifest.json').read_text())
    assert expected_model['revision'] == '08231374eeacb049a0eade7922910865b8fce912'
    for entry in expected_model['files']:
        assert digest(model / entry['name']) == entry['sha256'], 'Pinned model hash mismatch: ' + entry['name']
    expected_prompt = json.loads((evidence / 'run-01/prompt-ids.json').read_text())
    manifest['binary_sha256'] = digest(binary)
    manifest['verified_model'] = expected_model
    manifest['started_at_utc'] = datetime.now(timezone.utc).isoformat()
    out.mkdir(parents=True)
    # This is an application cache directory shared by this sample, not a prompt cache.
    env['MLXCEL_CACHE_DIR'] = str(out / 'runtime-cache')
    env.update(flags)
    save(out / 'manifest.json', manifest)
    sequences, results = [], []
    for i in range(1, args.runs + 1):
        folder = out / f'run-{i:02d}'
        folder.mkdir()
        argv = [str(binary), 'generate', '-m', str(model), '-p', PROMPT, '-n', '800', '--temp', '0']
        try:
            proc = subprocess.run(argv, env=env, capture_output=True, timeout=600)
            if args.save_private_raw:
                (folder / 'PRIVATE-stdout.txt').write_bytes(proc.stdout)
                (folder / 'PRIVATE-stderr.txt').write_bytes(proc.stderr)
            assert proc.returncode == 0, f'CLI return code {proc.returncode}'
            generated, arrays = parse(proc.stdout, proc.stderr)
            assert arrays['prompt'] == expected_prompt, 'Prompt-ID array differs from historical 67-token prompt; do not combine this arm'
            (folder / 'generated.txt').write_bytes(generated)
            save(folder / 'prompt-ids.json', arrays['prompt'])
            save(folder / 'token-ids.json', arrays['token'])
            result = {'run': folder.name, 'valid': True, 'returncode': proc.returncode,
                'generated_ids': len(arrays['token']), 'prompt_ids': len(arrays['prompt']),
                'text_sha256': digest(folder / 'generated.txt'), 'token_json_sha256': digest(folder / 'token-ids.json')}
            sequences.append(tuple(arrays['token']))
        except Exception as exc:
            result = {'run': folder.name, 'valid': False, 'error_type': type(exc).__name__,
                'error': 'Generation, model, or prompt validation failed. Run separately with --save-private-raw to inspect local logs; do not upload raw logs without review.'}
        save(folder / 'result.json', result)
        results.append(result)
        print(json.dumps(result), flush=True)
    summary = {'requested_runs': args.runs, 'valid_runs': len(sequences),
        'invalid_runs': len(results) - len(sequences), 'distinct_token_arrays': len(set(sequences)),
        'token_json_hash_counts': dict(Counter(r['token_json_sha256'] for r in results if r['valid'])),
        'results': results, 'sampling': manifest['sampling'],
        'interpretation': 'Identical bounded samples do not establish universal determinism; compare exact source/runtime/flags before combining.'}
    save(out / 'summary.json', summary)
    return 0 if len(sequences) == args.runs and len(set(sequences)) == 1 else 1


if __name__ == '__main__':
    sys.exit(main())
