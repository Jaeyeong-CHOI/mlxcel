# Sanitized fresh reproduction evidence

Finite observations are not a proof of determinism, semantic correctness, or root cause. Cache-state/path differences are distinct from within-arm variability. Token strings/bytes in server logprobs are not necessarily numeric token IDs. Logprob requests can alter decode scheduling. Library filename suffixes are evidence of loaded filenames, not an independently queried full runtime version. No service snapshots, raw process maps, raw logs, private environment, paths or weights are included.

Partial: False. A partial bundle excludes invalid/missing requests; never report its selected subset as a completed planned matrix.

Output comparisons exclude response IDs and timestamps. Runtime path variables are named but their values are omitted. Raw service/environment files and logs are deliberately absent. Public metadata uses command path placeholders.

CLI PASS means one observed output/token sequence in the finite sample only. Server logprobs, if present, are a separately observable scheduling condition. No throughput claim is made.

Verify offline: `python3 export_current.py verify BUNDLE_DIR` (use the exporter supplied alongside this bundle).

Hash semantics: SHA256SUMS hashes file bytes. In fresh CLI metadata, prompt_ids_sha256 and token_ids_sha256 (and summary token_hashes) hash compact JSON with sorted keys, ensure_ascii=False and separators=(",", ":"), with no trailing newline. source_*_file_sha256 preserves the original serialized-file hash. Server output hashes use the same canonical serialization for normalized assistant output, excluding response IDs and timestamps.
