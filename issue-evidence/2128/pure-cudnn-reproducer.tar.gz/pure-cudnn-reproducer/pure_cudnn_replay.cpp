// Diagnostic only: fixed-input Qwen3 decode SDPA, cuDNN frontend v1.16.0.
// No MLX, CUDA graph, RNG, inference model, or input conversion.
#include <cuda_runtime.h>
#include <cudnn.h>
#include <cudnn_frontend.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

namespace fs = std::filesystem;
namespace fe = cudnn_frontend;
static_assert(CUDNN_FRONTEND_VERSION == 11600, "Use pinned cudnn-frontend v1.16.0 headers");
static_assert(sizeof(float) == 4 && sizeof(int32_t) == 4, "32-bit float/int required");
constexpr std::size_t Q_BYTES = 1 * 16 * 1 * 128 * 2;
constexpr std::size_t KV_BYTES = 1 * 8 * 512 * 128 * 2;
constexpr int32_t LIVE_KV = 259;
constexpr int32_t LIVE_Q = 1;
enum : int64_t { Q = 1, K, V, O, SCALE, LEN_Q, LEN_KV };

static void fail(const std::string& s) { throw std::runtime_error(s); }
static void ck(cudaError_t e, const char* where) {
  if (e != cudaSuccess) fail(std::string(where) + ": " + cudaGetErrorString(e));
}
static void ck(cudnnStatus_t e, const char* where) {
  if (e != CUDNN_STATUS_SUCCESS) fail(std::string(where) + ": " + cudnnGetErrorString(e));
}
static void ck(fe::error_t e, const char* where) {
  if (e.is_bad()) fail(std::string(where) + ": " + e.get_message());
}
#define CHECK(x) ck((x), #x)

static std::string quote(const std::string& s) {
  std::ostringstream o;
  o << '"';
  for (unsigned char c : s) {
    if (c == '"' || c == '\\') o << '\\' << c;
    else if (c < 32) o << "\\u" << std::hex << std::setw(4) << std::setfill('0') << int(c) << std::dec;
    else o << c;
  }
  o << '"';
  return o.str();
}
static std::string hex64(uint64_t n) {
  std::ostringstream o;
  o << std::hex << std::setw(16) << std::setfill('0') << n;
  return o.str();
}
// Compact diagnostic fingerprint, NOT a cryptographic SHA256.
static uint64_t fnv1a(const std::vector<uint8_t>& bytes) {
  uint64_t h = UINT64_C(14695981039346656037);
  for (auto c : bytes) { h ^= c; h *= UINT64_C(1099511628211); }
  return h;
}
static std::vector<uint8_t> read_exact(const fs::path& p, std::size_t n) {
  if (!fs::is_regular_file(p) || fs::file_size(p) != n)
    fail("wrong/missing input size: " + p.string() + ", expected " + std::to_string(n));
  std::ifstream f(p, std::ios::binary);
  f.exceptions(std::ios::badbit | std::ios::failbit);
  std::vector<uint8_t> b(n);
  f.read(reinterpret_cast<char*>(b.data()), static_cast<std::streamsize>(n));
  return b;
}
static void write_bytes(const fs::path& p, const std::vector<uint8_t>& b) {
  std::ofstream f(p, std::ios::binary);
  f.exceptions(std::ios::badbit | std::ios::failbit);
  f.write(reinterpret_cast<const char*>(b.data()), static_cast<std::streamsize>(b.size()));
  f.close();
}
static uint16_t bits_at(const std::vector<uint8_t>& b, std::size_t i) {
  return static_cast<uint16_t>(b.at(i * 2)) | (static_cast<uint16_t>(b.at(i * 2 + 1)) << 8);
}
static float bf16(uint16_t bits) {
  uint32_t u = static_cast<uint32_t>(bits) << 16;
  float f;
  std::memcpy(&f, &u, sizeof f);
  return f;
}
static bool all_finite(const std::vector<uint8_t>& b) {
  for (std::size_t i = 0; i < b.size() / 2; ++i)
    if (!std::isfinite(bf16(bits_at(b, i)))) return false;
  return true;
}
static std::string address(const void* p) {
  std::ostringstream o;
  o << p;
  return o.str();
}
struct DeviceBuffer {
  void* p = nullptr;
  std::size_t size;
  explicit DeviceBuffer(std::size_t n) : size(n) { CHECK(cudaMalloc(&p, n)); }
  ~DeviceBuffer() { if (p) cudaFree(p); }
  DeviceBuffer(const DeviceBuffer&) = delete;
  DeviceBuffer& operator=(const DeviceBuffer&) = delete;
  void upload(const void* h, std::size_t n) {
    if (n != size) fail("upload size mismatch");
    CHECK(cudaMemcpy(p, h, n, cudaMemcpyHostToDevice));
  }
  std::vector<uint8_t> download() const {
    std::vector<uint8_t> b(size);
    CHECK(cudaMemcpy(b.data(), p, size, cudaMemcpyDeviceToHost));
    return b;
  }
};
struct Session {
  cudaStream_t stream = nullptr;
  cudnnHandle_t handle = nullptr;
  Session() {
    CHECK(cudaSetDevice(0));
    CHECK(cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking));
    CHECK(cudnnCreate(&handle));
    CHECK(cudnnSetStream(handle, stream));
  }
  ~Session() {
    if (handle) cudnnDestroy(handle);
    if (stream) cudaStreamDestroy(stream);
  }
};
class AuditGraph : public fe::graph::Graph {
 public:
  const fe::ExecutionPlan& selected() const {
    CHECK(plans.is_plan_index_executable(plans.candidate));
    return *plans.execution_plans.at(static_cast<std::size_t>(plans.candidate));
  }
};
static std::shared_ptr<fe::graph::Tensor_attributes> tensor(
    AuditGraph& g, const char* name, int64_t uid, std::vector<int64_t> dims,
    std::vector<int64_t> strides, fe::DataType_t type) {
  return g.tensor(fe::graph::Tensor_attributes().set_name(name).set_uid(uid)
      .set_dim(dims).set_stride(strides).set_data_type(type).set_alignment(32));
}

static int run(int argc, char** argv) {
  if (argc != 6)
    fail("usage: pure_cudnn_replay q.bin k_backing.bin v_backing.bin NEW_OUTPUT_DIR EXECUTIONS_GE_100");
  uint16_t endian = 1;
  if (*reinterpret_cast<uint8_t*>(&endian) != 1) fail("little-endian host required");
  const std::string count_text(argv[5]);
  if (count_text.empty() || count_text.find_first_not_of("0123456789") != std::string::npos)
    fail("execution count must be an integer >=100");
  unsigned long long parsed = std::stoull(count_text);
  if (parsed < 100 || parsed > 1000000) fail("execution count must be in [100,1000000]");
  const std::size_t count = static_cast<std::size_t>(parsed);
  const auto q = read_exact(argv[1], Q_BYTES);
  const auto k = read_exact(argv[2], KV_BYTES);
  const auto v = read_exact(argv[3], KV_BYTES);
  if (!all_finite(q) || !all_finite(k) || !all_finite(v)) fail("input contains NaN/Inf");
  const fs::path dir(argv[4]);
  if (fs::exists(dir)) fail("output directory already exists: " + dir.string());
  if (!fs::create_directories(dir)) fail("failed to create new output directory");
  std::ofstream log(dir / "records.jsonl");
  log.exceptions(std::ios::badbit | std::ios::failbit);
  log << std::setprecision(17);
  auto emit = [&](const std::string& s) { log << s << '\n'; log.flush(); };

  try {
    Session session;
    cudaDeviceProp properties{};
    CHECK(cudaGetDeviceProperties(&properties, 0));
    int runtime_version = 0, driver_version = 0;
    CHECK(cudaRuntimeGetVersion(&runtime_version));
    CHECK(cudaDriverGetVersion(&driver_version));
    const auto cudnn_version = cudnnGetVersion();
    if (cudnn_version < 90000) fail("cuDNN 9+ required");

    DeviceBuffer dq(Q_BYTES), dk(KV_BYTES), dv(KV_BYTES), dout(Q_BYTES);
    DeviceBuffer dqlen(sizeof LIVE_Q), dkvlen(sizeof LIVE_KV);
    dq.upload(q.data(), q.size()); dk.upload(k.data(), k.size()); dv.upload(v.data(), v.size());
    dqlen.upload(&LIVE_Q, sizeof LIVE_Q); dkvlen.upload(&LIVE_KV, sizeof LIVE_KV);
    // One initial NaN poison detects incomplete output writes; never reset between executions.
    CHECK(cudaMemset(dout.p, 0xff, Q_BYTES));
    CHECK(cudaDeviceSynchronize());
    const auto qlen_ref = dqlen.download(), kvlen_ref = dkvlen.download();
    if (dq.download() != q || dk.download() != k || dv.download() != v)
      fail("input upload readback mismatch");
    int32_t qlen_read = 0, kvlen_read = 0;
    std::memcpy(&qlen_read, qlen_ref.data(), 4); std::memcpy(&kvlen_read, kvlen_ref.data(), 4);
    if (qlen_read != LIVE_Q || kvlen_read != LIVE_KV) fail("length upload readback mismatch");

    AuditGraph graph;
    graph.set_io_data_type(fe::DataType_t::BFLOAT16)
         .set_intermediate_data_type(fe::DataType_t::FLOAT)
         .set_compute_data_type(fe::DataType_t::FLOAT);
    auto qt = tensor(graph, "Q", Q, {1,16,1,128}, {2048,128,128,1}, fe::DataType_t::BFLOAT16);
    auto kt = tensor(graph, "K", K, {1,8,512,128}, {524288,65536,128,1}, fe::DataType_t::BFLOAT16);
    auto vt = tensor(graph, "V", V, {1,8,512,128}, {524288,65536,128,1}, fe::DataType_t::BFLOAT16);
    auto qlt = tensor(graph, "SEQ_LEN_Q", LEN_Q, {1,1,1,1}, {1,1,1,1}, fe::DataType_t::INT32);
    auto kvlt = tensor(graph, "SEQ_LEN_KV", LEN_KV, {1,1,1,1}, {1,1,1,1}, fe::DataType_t::INT32);
    // Match MLX pass-by-value scale; it is a host float, not a device pointer.
    auto st = graph.tensor(fe::graph::Tensor_attributes().set_name("Scale").set_uid(SCALE)
        .set_dim({1,1,1,1}).set_stride({1,1,1,1}).set_is_pass_by_value(true)
        .set_data_type(fe::DataType_t::FLOAT));
    auto options = fe::graph::SDPA_attributes().set_name("sdpa_cudnn")
        .set_attn_scale(st).set_generate_stats(false).set_padding_mask(true)
        .set_seq_len_q(qlt).set_seq_len_kv(kvlt);
    // No causal mask, bias, dropout, or sinks.
    auto [ot, stats] = graph.sdpa(qt, kt, vt, options);
    (void)stats;
    ot->set_uid(O).set_dim({1,16,1,128}).set_stride({2048,128,128,1})
      .set_data_type(fe::DataType_t::BFLOAT16).set_alignment(32).set_output(true);
    CHECK(graph.validate());
    CHECK(graph.build_operation_graph(session.handle));
    CHECK(graph.create_execution_plans({fe::HeurMode_t::A}));
    graph.select_behavior_notes({fe::BehaviorNote_t::SUPPORTS_CUDA_GRAPH_NATIVE_API});
    CHECK(graph.check_support(session.handle));
    CHECK(graph.build_plans(session.handle));
    std::string plan_name;
    int64_t workspace_bytes = -1;
    CHECK(graph.get_plan_name(plan_name));
    CHECK(graph.get_workspace_size(workspace_bytes));
    if (workspace_bytes < 0) fail("negative workspace");
    // A one-byte sentinel avoids the frontend's null+0 pointer arithmetic for a zero-workspace plan.
    DeviceBuffer workspace(static_cast<std::size_t>(std::max<int64_t>(1, workspace_bytes)));
    float scale = 1.0f / std::sqrt(128.0f);
    uint32_t scale_bits = 0;
    std::memcpy(&scale_bits, &scale, sizeof scale);
    std::unordered_map<int64_t, void*> pack{{Q,dq.p},{K,dk.p},{V,dv.p},{O,dout.p},
        {SCALE,&scale},{LEN_Q,dqlen.p},{LEN_KV,dkvlen.p}};

    std::ostringstream meta;
    meta << std::setprecision(17) << "{\"event\":\"metadata\",\"schema\":1,\"backend\":\"pure_cudnn_direct\""
         << ",\"expected_executions\":" << count << ",\"cudnn_runtime\":" << cudnn_version
         << ",\"cudnn_headers\":" << CUDNN_VERSION << ",\"cuda_runtime\":" << runtime_version
         << ",\"cuda_driver\":" << driver_version << ",\"device\":" << quote(properties.name)
         << ",\"sm_major\":" << properties.major << ",\"sm_minor\":" << properties.minor
         << ",\"frontend\":\"" << CUDNN_FRONTEND_MAJOR_VERSION << '.' << CUDNN_FRONTEND_MINOR_VERSION
         << '.' << CUDNN_FRONTEND_PATCH_VERSION << "\",\"plan\":" << quote(plan_name)
         << ",\"plan_description\":" << quote(graph.selected().describe())
         << ",\"numeric_notes\":[";
    bool sep = false;
    for (auto note : graph.selected().getAllNumericNotes()) {
      if (sep) meta << ',';
      meta << static_cast<int>(note); sep = true;
    }
    meta << "],\"workspace_bytes\":" << workspace_bytes
         << ",\"workspace_allocated_bytes\":" << workspace.size
         << ",\"q_dims\":[1,16,1,128],\"kv_dims\":[1,8,512,128],\"live_q\":1,\"live_kv\":259"
         << ",\"q_strides\":[2048,128,128,1],\"kv_strides\":[524288,65536,128,1]"
         << ",\"dtype\":\"bf16_le\",\"scale\":" << scale << ",\"scale_f32_bits\":" << scale_bits
         << ",\"q_file\":" << quote(fs::absolute(argv[1]).string())
         << ",\"k_file\":" << quote(fs::absolute(argv[2]).string())
         << ",\"v_file\":" << quote(fs::absolute(argv[3]).string())
         << ",\"q_fnv1a64\":" << quote(hex64(fnv1a(q)))
         << ",\"k_fnv1a64\":" << quote(hex64(fnv1a(k)))
         << ",\"v_fnv1a64\":" << quote(hex64(fnv1a(v)))
         << ",\"q_ptr\":" << quote(address(dq.p)) << ",\"k_ptr\":" << quote(address(dk.p))
         << ",\"v_ptr\":" << quote(address(dv.p)) << ",\"o_ptr\":" << quote(address(dout.p))
         << ",\"len_q_ptr\":" << quote(address(dqlen.p)) << ",\"len_kv_ptr\":" << quote(address(dkvlen.p)) << '}';
    emit(meta.str());
    std::cout << "plan=" << plan_name << " workspace=" << workspace_bytes
              << " cudnn=" << cudnn_version << " executions=" << count << '\n';

    std::vector<uint8_t> reference;
    std::size_t mismatches = 0, input_changes = 0, nonfinite_runs = 0, completed = 0;
    for (std::size_t iteration = 0; iteration < count; ++iteration) {
      CHECK(graph.execute(session.handle, pack, workspace.p));
      CHECK(cudaPeekAtLastError());
      CHECK(cudaStreamSynchronize(session.stream));
      const auto output = dout.download();
      // Compare complete physical input allocations and GPU length scalars every time.
      const auto q_after = dq.download(), k_after = dk.download(), v_after = dv.download();
      const auto qlen_after = dqlen.download(), kvlen_after = dkvlen.download();
      const bool inputs_equal = q_after == q && k_after == k && v_after == v
          && qlen_after == qlen_ref && kvlen_after == kvlen_ref;
      if (!inputs_equal) {
        ++input_changes;
        write_bytes(dir / ("q-after-" + std::to_string(iteration) + ".bin"), q_after);
        write_bytes(dir / ("k-after-" + std::to_string(iteration) + ".bin"), k_after);
        write_bytes(dir / ("v-after-" + std::to_string(iteration) + ".bin"), v_after);
        write_bytes(dir / ("qlen-after-" + std::to_string(iteration) + ".bin"), qlen_after);
        write_bytes(dir / ("kvlen-after-" + std::to_string(iteration) + ".bin"), kvlen_after);
      }
      const bool finite = all_finite(output);
      if (!finite) ++nonfinite_runs;
      if (iteration == 0) {
        reference = output;
        write_bytes(dir / "reference.bf16.bin", reference);
      }
      const bool equal = output == reference;
      std::size_t changed = 0, first = Q_BYTES / 2;
      double max_delta = 0;
      if (!equal) {
        ++mismatches;
        std::ofstream diff(dir / ("diff-" + std::to_string(iteration) + ".tsv"));
        diff.exceptions(std::ios::badbit | std::ios::failbit);
        diff << "element\thead\tdim\treference_bits\tactual_bits\treference_f32\tactual_f32\tabs_delta\n";
        diff << std::setprecision(17);
        for (std::size_t i = 0; i < Q_BYTES / 2; ++i) {
          const uint16_t a = bits_at(reference, i), b = bits_at(output, i);
          if (a == b) continue;
          if (first == Q_BYTES / 2) first = i;
          ++changed;
          const double delta = std::abs(static_cast<double>(bf16(a)) - bf16(b));
          if (std::isfinite(delta)) max_delta = std::max(max_delta, delta);
          diff << i << '\t' << i / 128 << '\t' << i % 128 << '\t' << a << '\t' << b
               << '\t' << bf16(a) << '\t' << bf16(b) << '\t' << delta << '\n';
        }
        diff.close();
      }
      if (!equal || !finite)
        write_bytes(dir / ("output-" + std::to_string(iteration) + ".bf16.bin"), output);
      std::ostringstream row;
      row << std::setprecision(17) << "{\"event\":\"execution\",\"iteration\":" << iteration
          << ",\"output_fnv1a64\":" << quote(hex64(fnv1a(output)))
          << ",\"matches_reference\":" << (equal ? "true" : "false")
          << ",\"inputs_unchanged\":" << (inputs_equal ? "true" : "false")
          << ",\"all_finite\":" << (finite ? "true" : "false")
          << ",\"changed_elements\":" << changed << ",\"first_diff_index\":";
      if (changed) row << first; else row << "null";
      row << ",\"max_abs_finite_delta\":" << max_delta << '}';
      emit(row.str());
      ++completed;
      // An input mutation is an invalid fixed-input experiment: do not continue on corrupted inputs.
      if (!inputs_equal) fail("device input/length mutation; diagnostic artifacts saved");
    }
    if (completed != count) fail("incomplete execution grid");
    const bool passed = mismatches == 0 && input_changes == 0 && nonfinite_runs == 0;
    std::ostringstream summary;
    summary << "{\"event\":\"final_summary\",\"completed_executions\":" << completed
            << ",\"expected_executions\":" << count << ",\"comparisons\":" << count - 1
            << ",\"mismatches\":" << mismatches << ",\"input_changes\":" << input_changes
            << ",\"nonfinite_runs\":" << nonfinite_runs
            << ",\"all_passed\":" << (passed ? "true" : "false") << '}';
    emit(summary.str());
    std::cout << summary.str() << '\n';
    log.close();
    return passed ? 0 : 1;
  } catch (const std::exception& e) {
    // No successful final_summary is produced on API, I/O, or coverage failure.
    try { emit("{\"event\":\"error\",\"message\":" + quote(e.what()) + '}'); } catch (...) {}
    throw;
  }
}
int main(int argc, char** argv) {
  try { return run(argc, argv); }
  catch (const std::exception& e) {
    std::cerr << "ERROR: " << e.what() << '\n';
    return 2;
  }
}
