# Fixed-input BF16 SDPA: pure cuDNN reproducer

**Local diagnostic review bundle; not submitted or newly GPU-tested during packaging.** This is the exact C++ source and Q/K/V byte payload used in the completed runs below. It does not link MLX, load a model, create an application CUDA graph, use randomness, or convert its inputs.

## Recorded result

NVIDIA GB10 / SM 12.1, CUDA runtime 13.0, cuDNN frontend **1.16.0**, compiled cuDNN headers 9.13.0. The same executable and fixed inputs were run with two runtime library versions:

| cuDNN runtime | Executions | Comparisons to execution 0 | Different outputs | Input/length changes | Nonfinite outputs |
|---|---:|---:|---:|---:|---:|
| 9.13.0 (`91300`) | 1,000 | 999 | 615 | 0 | 0 |
| 9.24.1 (`92401`) | 1,000 | 999 | 679 | 0 | 0 |

Both runs produced the same two complete output byte arrays. Their sole difference is BF16 element **1086** (head 8, channel 62), one adjacent representable step. Plan selection differed between runtimes; selected plan strings and record-file hashes are in `observed-results.json`. Neither plan advertised a `NONDETERMINISTIC` numeric note; absence of that note is not a general determinism guarantee.

These results localize this finite output variation to the directly exercised cuDNN path on this host. They do **not** identify atomics, reduction order, a race, a hardware fault or a specific internal kernel mechanism; nor do they establish behavior on every shape/GPU/version. The archived 9.13 support matrix does not explicitly list CC 12.1; 9.24.1 does. The newer-runtime reproduction is therefore important to the platform qualification. See NVIDIA's [9.13 matrix](https://docs.nvidia.com/deeplearning/cudnn/backend/v9.13.0/reference/support-matrix.html) and [9.24.1 matrix](https://docs.nvidia.com/deeplearning/cudnn/backend/v9.24.1/reference/support-matrix.html).

## Payload and operation

| File | BF16 little-endian shape | Bytes |
|---|---|---:|
| `inputs/q.bin` | `[1,16,1,128]` | 4,096 |
| `inputs/k.bin` | `[1,8,512,128]` | 1,048,576 |
| `inputs/v.bin` | `[1,8,512,128]` | 1,048,576 |

K/V are the **whole physical backing**, not just the live prefix. GPU INT32 lengths are Q=1 and KV=259. Scale is host FP32 `1/sqrt(128)`; FP32 intermediate/compute, inference, padding mask, no causal mask/bias/dropout/sinks/statistics. Input provenance and hashes are preserved in `inputs/manifest.json`. Its `source` fields are historical relative evidence labels, not additional required files.

One nonblocking CUDA stream, one cuDNN handle, heuristic A and the original native-graph-capability plan filter are used. Execution itself is direct `graph.execute`: selecting a CUDA-graph-capable plan does not create a CUDA graph. All application-owned pointers stay fixed. Every execution is synchronized, then complete device Q/K/V and length bytes are rechecked. The first output is the comparison reference. Output is NaN-poisoned once; zero required workspace uses a one-byte unused nonnull allocation.

## Verify and build

From this directory on a supported **Linux NVIDIA CUDA** host:

```bash
sha256sum -c SHA256SUMS
```

Provide CUDA **13.0**, cuDNN 9 headers/libraries, and the header-only [NVIDIA cuDNN frontend tag v1.16.0](https://github.com/NVIDIA/cudnn-frontend/tree/v1.16.0). Headers/libraries and a compiler are intentionally not bundled. The source statically rejects a different frontend version. Use your own installation paths:

```bash
REPLAY_CUDA_INCLUDE=/path/to/cuda-13.0/include
REPLAY_CUDA_LIB=/path/to/cuda-13.0/lib64
REPLAY_FRONTEND_INCLUDE=/path/to/cudnn-frontend-1.16.0/include
REPLAY_CUDNN_INCLUDE=/path/to/cudnn-9.13.0/include
REPLAY_CUDNN_LIB=/path/to/cudnn-9.13.0/lib

g++ -std=c++17 -O2 -Wall -Wextra -DCUDNN_FRONTEND_SKIP_JSON_LIB \
  -I"$REPLAY_CUDA_INCLUDE" -I"$REPLAY_FRONTEND_INCLUDE" \
  -I"$REPLAY_CUDNN_INCLUDE" pure_cudnn_replay.cpp \
  -L"$REPLAY_CUDA_LIB" -L"$REPLAY_CUDNN_LIB" \
  -lcudnn -lcudart -ldl -o pure-cudnn-replay
```

This is a portable build recipe, not a new compilation result. No `-ffast-math`, custom CUDA kernel, MLX dependency, or frontend dynamic-loading macro is needed. `CUDNN_FRONTEND_SKIP_JSON_LIB` disables optional frontend JSON serialization; this program writes its own JSONL and does not call that serializer. Keep the complete selected runtime's split cuDNN libraries together. The CUDA library directory must also make required CUDA dependencies such as NVRTC/cuBLAS available.

## Run

Use an idle/authorized GPU. The output directory **must not already exist**; run from this bundle directory:

```bash
LD_LIBRARY_PATH="$REPLAY_CUDNN_LIB:$REPLAY_CUDA_LIB" \
  ./pure-cudnn-replay inputs/q.bin inputs/k.bin inputs/v.bin outputs/cudnn913-run1 1000
```

To compare 9.24.1, keep the binary and input files unchanged, set `REPLAY_CUDNN_LIB` to that version's complete CUDA-13 runtime directory, and use a fresh output path. This changes only the process's loader path, not any installed runtime. Record binary SHA256 and loader resolution (`ldd` plus any needed dynamic-loader trace); the program records `cudnnGetVersion`, CUDA/header/frontend versions and selected plan. Do not mix split libraries from different cuDNN versions. GPU/device properties are recorded; the program uses device 0 visible to the process.

## Exit codes and interpretation

- **0:** complete grid, finite output, unchanged inputs/lengths, all outputs match the first.
- **1:** complete grid with different output bytes or nonfinite output. Inspect the counters: nonfinite-only failure is not evidence of nondeterminism.
- **2:** invalid arguments/input, unavailable plan, API/I/O failure or mutated input/length bytes. An incomplete run is not PASS.

For 1,000 executions require metadata + exactly 1,000 ordered execution rows + final summary: **1,002 records**, 999 comparisons. `records.jsonl`, first output, every different output and TSV element differences are written. Report actual counters and selected plan rather than expecting the historical counts or engine names to recur. A stable run on another configuration does not invalidate the preserved result.

`observed-outputs/variant-{a,b}.bf16.bin` are two small **observed examples, not golden correctness assertions**. The program does not load them. Full original logs and all 1,294 changed outputs/TSVs were independently audited and remain in the private evidence archive; this compact bundle includes only sanitized summaries and their SHA256 references. Newly produced logs contain the executing machine's absolute input paths, so review them before any later sharing. No machine-specific user paths, service files, credentials, model weights or large logs are included here.
