// Diagnostic only: matched-header/runtime fixed-input SDPA probe, frontend v1.16.0 or v1.30.0.
// No MLX, CUDA graph, RNG, inference model, or input conversion.
#include <cuda_runtime.h>
#include <cudnn.h>
#include <cudnn_frontend.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

namespace fs = std::filesystem;
namespace fe = cudnn_frontend;
static_assert(CUDNN_FRONTEND_VERSION == 11600 || CUDNN_FRONTEND_VERSION == 13000,
              "Use pinned cudnn-frontend v1.16.0 or v1.30.0 headers");
#ifdef CUDNN_FRONTEND_SKIP_JSON_LIB
#error "This diagnostic requires graph JSON provenance; do not disable frontend JSON support"
#endif
static_assert(sizeof(float) == 4 && sizeof(int32_t) == 4, "32-bit float/int required");
constexpr std::size_t Q_BYTES = 1 * 16 * 1 * 128 * 2;
constexpr std::size_t KV_BYTES = 1 * 8 * 512 * 128 * 2;
constexpr int32_t LIVE_KV = 259;
constexpr int32_t LIVE_Q = 1;
enum : int64_t { Q = 1, K, V, O, SCALE, LEN_Q, LEN_KV, STATS };

static void fail(const std::string& s) { throw std::runtime_error(s); }
static void ck(cudaError_t e, const char* where) {
  if (e != cudaSuccess) fail(std::string(where) + ": " + cudaGetErrorString(e));
}
static void ck(cudnnStatus_t e, const char* where) {
  if (e != CUDNN_STATUS_SUCCESS) fail(std::string(where) + ": " + cudnnGetErrorString(e));
}
static void ck(fe::error_t e, const char* where) {
  if (e.is_bad()) fail(std::string(where) + ": " + e.get_message());
}
#define CHECK(x) ck((x), #x)

static std::string quote(const std::string& s) {
  std::ostringstream o;
  o << '"';
  for (unsigned char c : s) {
    if (c == '"' || c == '\\') o << '\\' << c;
    else if (c < 32) o << "\\u" << std::hex << std::setw(4) << std::setfill('0') << int(c) << std::dec;
    else o << c;
  }
  o << '"';
  return o.str();
}
static std::string hex64(uint64_t n) {
  std::ostringstream o;
  o << std::hex << std::setw(16) << std::setfill('0') << n;
  return o.str();
}
// Compact diagnostic fingerprint, NOT a cryptographic SHA256.
static uint64_t fnv1a(const std::vector<uint8_t>& bytes) {
  uint64_t h = UINT64_C(14695981039346656037);
  for (auto c : bytes) { h ^= c; h *= UINT64_C(1099511628211); }
  return h;
}
static std::vector<uint8_t> read_exact(const fs::path& p, std::size_t n) {
  if (!fs::is_regular_file(p) || fs::file_size(p) != n)
    fail("wrong/missing input size: " + p.string() + ", expected " + std::to_string(n));
  std::ifstream f(p, std::ios::binary);
  f.exceptions(std::ios::badbit | std::ios::failbit);
  std::vector<uint8_t> b(n);
  f.read(reinterpret_cast<char*>(b.data()), static_cast<std::streamsize>(n));
  return b;
}
static void write_bytes(const fs::path& p, const std::vector<uint8_t>& b) {
  std::ofstream f(p, std::ios::binary);
  f.exceptions(std::ios::badbit | std::ios::failbit);
  f.write(reinterpret_cast<const char*>(b.data()), static_cast<std::streamsize>(b.size()));
  f.close();
}
static uint16_t bits_at(const std::vector<uint8_t>& b, std::size_t i) {
  return static_cast<uint16_t>(b.at(i * 2)) | (static_cast<uint16_t>(b.at(i * 2 + 1)) << 8);
}
static float bf16(uint16_t bits) {
  uint32_t u = static_cast<uint32_t>(bits) << 16;
  float f;
  std::memcpy(&f, &u, sizeof f);
  return f;
}
static bool all_finite(const std::vector<uint8_t>& b) {
  for (std::size_t i = 0; i < b.size() / 2; ++i)
    if (!std::isfinite(bf16(bits_at(b, i)))) return false;
  return true;
}
static std::string address(const void* p) {
  std::ostringstream o;
  o << p;
  return o.str();
}
struct DeviceBuffer {
  void* p = nullptr;
  std::size_t size;
  explicit DeviceBuffer(std::size_t n) : size(n) { CHECK(cudaMalloc(&p, n)); }
  ~DeviceBuffer() { if (p) cudaFree(p); }
  DeviceBuffer(const DeviceBuffer&) = delete;
  DeviceBuffer& operator=(const DeviceBuffer&) = delete;
  void upload(const void* h, std::size_t n) {
    if (n != size) fail("upload size mismatch");
    CHECK(cudaMemcpy(p, h, n, cudaMemcpyHostToDevice));
  }
  std::vector<uint8_t> download() const {
    std::vector<uint8_t> b(size);
    CHECK(cudaMemcpy(b.data(), p, size, cudaMemcpyDeviceToHost));
    return b;
  }
};

static std::string env(const char* key, const char* fallback) {
  const char* value = std::getenv(key);
  return value ? value : fallback;
}
static long long integer(const std::string& s, long long low, long long high, const char* key) {
  std::size_t n = 0;
  const auto value = std::stoll(s, &n);
  if (n != s.size() || value < low || value > high) fail(std::string("invalid ") + key + ": " + s);
  return value;
}
static bool flag(const char* key, bool fallback) {
  return integer(env(key, fallback ? "1" : "0"), 0, 1, key) != 0;
}
struct Config {
  bool f32 = false, stats = false, device_sync = false, device_scale = false;
  bool padding = true, native_filter = true, fresh_pack = true;
  int poison = 255, workspace_poison = -1, capacity = 512;
  int64_t plan_index = -1;
  std::string stream = "nonblocking", heuristic = "A", implementation = "auto";
  Config() {
    const auto dtype = env("PROBE_OUTPUT", "bf16");
    if (dtype != "bf16" && dtype != "fp32") fail("PROBE_OUTPUT must be bf16 or fp32");
    f32 = dtype == "fp32";
    stats = flag("PROBE_STATS", false);
    device_sync = flag("PROBE_DEVICE_SYNC", false);
    device_scale = flag("PROBE_DEVICE_SCALE", false);
    padding = flag("PROBE_PADDING", true);
    native_filter = flag("PROBE_NATIVE_FILTER", true);
    fresh_pack = flag("PROBE_FRESH_PACK", true);
    if (!fresh_pack) fail("PROBE_FRESH_PACK=0 is disallowed in matched-header comparisons");
    implementation = env("PROBE_IMPLEMENTATION", "auto");
    if (implementation != "auto" && implementation != "composite" && implementation != "unified")
      fail("PROBE_IMPLEMENTATION must be auto, composite, or unified");
    poison = static_cast<int>(integer(env("PROBE_POISON", "255"), -1, 255, "PROBE_POISON"));
    workspace_poison = static_cast<int>(integer(env("PROBE_WORKSPACE_POISON", "-1"), -1, 255, "PROBE_WORKSPACE_POISON"));
    capacity = static_cast<int>(integer(env("PROBE_CAPACITY", "512"), 259, 512, "PROBE_CAPACITY"));
    if (capacity != 259 && capacity != 512) fail("PROBE_CAPACITY must be 259 or 512");
    plan_index = integer(env("PROBE_PLAN_INDEX", "-1"), -1, 1000000, "PROBE_PLAN_INDEX");
    stream = env("PROBE_STREAM", "nonblocking");
    if (stream != "nonblocking" && stream != "blocking" && stream != "default") fail("invalid PROBE_STREAM");
    heuristic = env("PROBE_HEURISTIC", "A");
    if (heuristic != "A" && heuristic != "B" && heuristic != "FALLBACK") fail("invalid PROBE_HEURISTIC");
  }
};
struct Session {
  cudaStream_t stream = nullptr;
  cudnnHandle_t handle = nullptr;
  explicit Session(const Config& c) {
    CHECK(cudaSetDevice(0));
    if (c.stream != "default")
      CHECK(cudaStreamCreateWithFlags(&stream, c.stream == "blocking" ? cudaStreamDefault : cudaStreamNonBlocking));
    CHECK(cudnnCreate(&handle));
    CHECK(cudnnSetStream(handle, stream));
  }
  ~Session() {
    if (handle) cudnnDestroy(handle);
    if (stream) cudaStreamDestroy(stream);
  }
};
class AuditGraph : public fe::graph::Graph {
 public:
  int64_t candidate() const { return plans.candidate; }
  const fe::ExecutionPlan& selected(int64_t index) const {
    CHECK(plans.is_plan_index_executable(index));
    return *plans.execution_plans.at(static_cast<std::size_t>(index));
  }
};
static std::shared_ptr<fe::graph::Tensor_attributes> tensor(
    AuditGraph& g, const char* name, int64_t uid, std::vector<int64_t> dims,
    std::vector<int64_t> strides, fe::DataType_t type) {
  return g.tensor(fe::graph::Tensor_attributes().set_name(name).set_uid(uid)
      .set_dim(dims).set_stride(strides).set_data_type(type).set_alignment(32));
}
static std::vector<uint8_t> repack(const std::vector<uint8_t>& b, int capacity) {
  if (capacity == 512) return b;
  const std::size_t head_bytes = static_cast<std::size_t>(capacity) * 128 * 2;
  std::vector<uint8_t> packed(8 * head_bytes);
  for (std::size_t head = 0; head < 8; ++head)
    std::copy_n(b.begin() + head * 512 * 128 * 2, head_bytes, packed.begin() + head * head_bytes);
  return packed;
}
static uint32_t element_bits(const std::vector<uint8_t>& b, std::size_t i, bool f32) {
  if (!f32) return bits_at(b, i);
  uint32_t bits;
  std::memcpy(&bits, b.data() + i * 4, 4);
  return bits;
}
static float element_value(uint32_t bits, bool f32) {
  if (!f32) return bf16(static_cast<uint16_t>(bits));
  float value;
  std::memcpy(&value, &bits, 4);
  return value;
}
static bool finite_buffer(const std::vector<uint8_t>& b, bool f32) {
  for (std::size_t i = 0; i < b.size() / (f32 ? 4 : 2); ++i)
    if (!std::isfinite(element_value(element_bits(b, i, f32), f32))) return false;
  return true;
}
struct Differences { std::size_t changed = 0, first = 0; double max_delta = 0; };
static Differences compare(const std::vector<uint8_t>& reference, const std::vector<uint8_t>& actual,
                           bool f32, const fs::path& diff_path = {}) {
  if (reference.size() != actual.size()) fail("comparison size mismatch");
  Differences result;
  std::ofstream diff;
  if (!diff_path.empty()) {
    diff.open(diff_path);
    diff.exceptions(std::ios::badbit | std::ios::failbit);
    diff << "element\treference_bits\tactual_bits\treference_f32\tactual_f32\tabs_delta\n" << std::setprecision(17);
  }
  for (std::size_t i = 0; i < actual.size() / (f32 ? 4 : 2); ++i) {
    const auto a = element_bits(reference, i, f32), b = element_bits(actual, i, f32);
    if (a == b) continue;
    if (!result.changed) result.first = i;
    ++result.changed;
    const auto av = element_value(a, f32), bv = element_value(b, f32);
    const double delta = std::abs(static_cast<double>(av) - bv);
    if (std::isfinite(delta)) result.max_delta = std::max(result.max_delta, delta);
    if (diff.is_open()) diff << i << '\t' << a << '\t' << b << '\t' << av << '\t' << bv << '\t' << delta << '\n';
  }
  return result;
}
// Unique outputs are identified by full bytes, never by a possibly colliding hash.
static std::size_t save_unique(std::vector<std::vector<uint8_t>>& seen, const std::vector<uint8_t>& bytes,
                               const fs::path& dir, const std::string& stem, bool f32) {
  const auto it = std::find(seen.begin(), seen.end(), bytes);
  if (it != seen.end()) return static_cast<std::size_t>(it - seen.begin());
  const auto index = seen.size();
  write_bytes(dir / (stem + "-" + std::to_string(index) + (f32 ? ".fp32.bin" : ".bf16.bin")), bytes);
  if (!seen.empty()) compare(seen.front(), bytes, f32, dir / (stem + "-" + std::to_string(index) + ".diff.tsv"));
  seen.push_back(bytes);
  return index;
}
static int run(int argc, char** argv) {
  if (argc != 6) fail("usage: pure_cudnn_probe q.bin k_backing.bin v_backing.bin NEW_OUTPUT_DIR EXECUTIONS_GE_1");
  uint16_t endian = 1;
  if (*reinterpret_cast<uint8_t*>(&endian) != 1) fail("little-endian host required");
  const Config c;
  const auto count = static_cast<std::size_t>(integer(argv[5], 1, 1000000, "EXECUTIONS"));
  const auto q = read_exact(argv[1], Q_BYTES);
  const auto k_source = read_exact(argv[2], KV_BYTES), v_source = read_exact(argv[3], KV_BYTES);
  if (!all_finite(q) || !all_finite(k_source) || !all_finite(v_source)) fail("input contains NaN/Inf");
  const auto k = repack(k_source, c.capacity), v = repack(v_source, c.capacity);
  const std::size_t output_bytes = 2048 * (c.f32 ? 4 : 2);
  const fs::path dir(argv[4]);
  if (fs::exists(dir)) fail("output directory already exists: " + dir.string());
  if (!fs::create_directories(dir)) fail("failed to create new output directory");
  std::ofstream log(dir / "records.jsonl");
  log.exceptions(std::ios::badbit | std::ios::failbit);
  auto emit = [&](const std::string& s) { log << s << '\n'; log.flush(); };
  std::ostringstream config;
  config << "{\"event\":\"configuration\",\"schema\":2,\"expected_executions\":" << count
         << ",\"output_dtype\":" << quote(c.f32 ? "fp32" : "bf16") << ",\"stats\":" << c.stats
         << ",\"poison_byte\":" << c.poison << ",\"workspace_poison_byte\":" << c.workspace_poison
         << ",\"device_sync\":" << c.device_sync << ",\"device_scale\":" << c.device_scale
         << ",\"padding\":" << c.padding << ",\"native_filter\":" << c.native_filter
         << ",\"fresh_pack\":" << c.fresh_pack
         << ",\"requested_implementation\":" << quote(c.implementation)
         << ",\"capacity\":" << c.capacity << ",\"effective_kv_length\":" << (c.padding ? LIVE_KV : c.capacity)
         << ",\"stream\":" << quote(c.stream) << ",\"heuristic\":" << quote(c.heuristic)
         << ",\"requested_plan_index\":" << c.plan_index
         << ",\"CUDA_LAUNCH_BLOCKING\":" << quote(env("CUDA_LAUNCH_BLOCKING", ""))
         << ",\"CUDNN_LOGLEVEL_DBG\":" << quote(env("CUDNN_LOGLEVEL_DBG", ""))
         << ",\"CUDNN_LOGDEST_DBG\":" << quote(env("CUDNN_LOGDEST_DBG", "")) << '}';
  emit(config.str());
  try {
    Session session(c);
    cudaDeviceProp properties{};
    CHECK(cudaGetDeviceProperties(&properties, 0));
    int runtime_version = 0, driver_version = 0;
    CHECK(cudaRuntimeGetVersion(&runtime_version)); CHECK(cudaDriverGetVersion(&driver_version));
    const auto cudnn_version = cudnnGetVersion();
    // Emit provenance before graph construction, so unsupported requested modes still have versions.
    std::ostringstream runtime_meta;
    runtime_meta << "{\"event\":\"runtime_metadata\",\"cudnn_runtime\":" << cudnn_version
                 << ",\"cudnn_headers\":" << CUDNN_VERSION
                 << ",\"frontend_version\":" << CUDNN_FRONTEND_VERSION
                 << ",\"cuda_headers\":" << CUDART_VERSION
                 << ",\"cuda_runtime\":" << runtime_version << ",\"cuda_driver\":" << driver_version
                 << ",\"device\":" << quote(properties.name)
                 << ",\"sm_major\":" << properties.major << ",\"sm_minor\":" << properties.minor
                 << ",\"requested_implementation\":" << quote(c.implementation) << '}';
    emit(runtime_meta.str());
    if (cudnn_version < 90000) fail("cuDNN 9+ required");
    DeviceBuffer dq(q.size()), dk(k.size()), dv(v.size()), dout(output_bytes);
    DeviceBuffer dqlen(4), dkvlen(4), dscale(4), dstats(16 * 4);
    float scale = 1.0f / std::sqrt(128.0f);
    uint32_t scale_bits;
    std::memcpy(&scale_bits, &scale, 4);
    dq.upload(q.data(), q.size()); dk.upload(k.data(), k.size()); dv.upload(v.data(), v.size());
    dqlen.upload(&LIVE_Q, 4); dkvlen.upload(&LIVE_KV, 4); dscale.upload(&scale, 4);
    CHECK(cudaMemsetAsync(dout.p, 255, dout.size, session.stream));
    CHECK(cudaMemsetAsync(dstats.p, 255, dstats.size, session.stream));
    CHECK(cudaStreamSynchronize(session.stream));
    CHECK(cudaDeviceSynchronize());
    const auto qlen_ref = dqlen.download(), kvlen_ref = dkvlen.download(), scale_ref = dscale.download();
    if (dq.download() != q || dk.download() != k || dv.download() != v) fail("input upload mismatch");
    int32_t qlen_read = 0, kvlen_read = 0;
    std::memcpy(&qlen_read, qlen_ref.data(), 4); std::memcpy(&kvlen_read, kvlen_ref.data(), 4);
    if (qlen_read != LIVE_Q || kvlen_read != LIVE_KV || element_bits(scale_ref, 0, true) != scale_bits)
      fail("scalar upload mismatch");
    AuditGraph graph;
    graph.set_io_data_type(fe::DataType_t::BFLOAT16)
         .set_intermediate_data_type(fe::DataType_t::FLOAT).set_compute_data_type(fe::DataType_t::FLOAT);
    auto qt = tensor(graph, "Q", Q, {1,16,1,128}, {2048,128,128,1}, fe::DataType_t::BFLOAT16);
    const int64_t head_stride = static_cast<int64_t>(c.capacity) * 128;
    auto kt = tensor(graph, "K", K, {1,8,c.capacity,128}, {8*head_stride,head_stride,128,1}, fe::DataType_t::BFLOAT16);
    auto vt = tensor(graph, "V", V, {1,8,c.capacity,128}, {8*head_stride,head_stride,128,1}, fe::DataType_t::BFLOAT16);
    auto st = graph.tensor(fe::graph::Tensor_attributes().set_name("Scale").set_uid(SCALE)
        .set_dim({1,1,1,1}).set_stride({1,1,1,1}).set_is_pass_by_value(!c.device_scale)
        .set_data_type(fe::DataType_t::FLOAT));
    auto options = fe::graph::SDPA_attributes().set_name("sdpa_cudnn")
        .set_attn_scale(st).set_generate_stats(c.stats).set_padding_mask(c.padding)
        .set_implementation(c.implementation == "unified" ? fe::AttentionImplementation_t::UNIFIED :
                            c.implementation == "composite" ? fe::AttentionImplementation_t::COMPOSITE :
                            fe::AttentionImplementation_t::AUTO);
    if (c.padding) {
      auto qlt = tensor(graph, "SEQ_LEN_Q", LEN_Q, {1,1,1,1}, {1,1,1,1}, fe::DataType_t::INT32);
      auto kvlt = tensor(graph, "SEQ_LEN_KV", LEN_KV, {1,1,1,1}, {1,1,1,1}, fe::DataType_t::INT32);
      options.set_seq_len_q(qlt).set_seq_len_kv(kvlt);
    }
    auto [ot, stats] = graph.sdpa(qt, kt, vt, options);
    ot->set_uid(O).set_dim({1,16,1,128}).set_stride({2048,128,128,1})
      .set_data_type(c.f32 ? fe::DataType_t::FLOAT : fe::DataType_t::BFLOAT16).set_alignment(32).set_output(true);
    if (c.stats) {
      if (!stats) fail("generate_stats returned no stats tensor");
      stats->set_uid(STATS).set_dim({1,16,1,1}).set_stride({16,1,1,1})
           .set_data_type(fe::DataType_t::FLOAT).set_alignment(32).set_output(true);
    }
    CHECK(graph.validate());
    // Graph::sdpa resolves AUTO internally. Read the stored node, not the caller's options copy.
    // Record this after validation and before backend support checks. Selection alone is not
    // successful execution of UNIFIED. Serialization does not execute the graph.
    nlohmann::json graph_json;
    graph.serialize(graph_json);
    std::ofstream graph_file(dir / "graph.json");
    graph_file.exceptions(std::ios::badbit | std::ios::failbit);
    graph_file << graph_json.dump(2) << '\n';
    graph_file.close();
    nlohmann::json resolved_implementation = nullptr;
    if (graph_json.contains("nodes")) {
      for (const auto& node : graph_json.at("nodes")) {
        if (node.value("name", std::string{}) == "sdpa_cudnn" && node.contains("implementation")) {
          if (!resolved_implementation.is_null()) fail("ambiguous serialized SDPA implementation");
          resolved_implementation = node.at("implementation");
        }
      }
    }
    emit("{\"event\":\"implementation_selection\",\"requested_implementation\":" + quote(c.implementation)
         + ",\"resolved_implementation\":" + resolved_implementation.dump()
         + ",\"source\":\"graph.json SDPA node implementation; selection is not support/execution success\"}");
    CHECK(graph.build_operation_graph(session.handle));
    const auto heuristic = c.heuristic == "A" ? fe::HeurMode_t::A :
        c.heuristic == "B" ? fe::HeurMode_t::B : fe::HeurMode_t::FALLBACK;
    CHECK(graph.create_execution_plans({heuristic}));
    if (c.native_filter) graph.select_behavior_notes({fe::BehaviorNote_t::SUPPORTS_CUDA_GRAPH_NATIVE_API});
    const auto plan_count = graph.get_execution_plan_count();
    emit("{\"event\":\"plan_candidates\",\"count\":" + std::to_string(plan_count) + '}');
    CHECK(graph.check_support(session.handle));
    int64_t selected_index;
    if (c.plan_index >= 0) {
      if (c.plan_index >= plan_count) fail("PROBE_PLAN_INDEX out of range");
      CHECK(graph.build_plan_at_index(session.handle, c.plan_index));
      selected_index = c.plan_index;
    } else {
      CHECK(graph.build_plans(session.handle)); selected_index = graph.candidate();
    }
    std::string plan_name;
    int64_t workspace_bytes = -1;
    CHECK(graph.get_plan_name_at_index(selected_index, plan_name));
    CHECK(graph.get_workspace_size_plan_at_index(selected_index, workspace_bytes));
    if (workspace_bytes < 0) fail("negative workspace");
    DeviceBuffer workspace(static_cast<std::size_t>(std::max<int64_t>(1, workspace_bytes)));
    std::unordered_map<int64_t, void*> pack{{Q,dq.p},{K,dk.p},{V,dv.p},{O,dout.p},
        {SCALE,c.device_scale ? dscale.p : static_cast<void*>(&scale)}};
    if (c.padding) { pack.emplace(LEN_Q,dqlen.p); pack.emplace(LEN_KV,dkvlen.p); }
    if (c.stats) pack.emplace(STATS,dstats.p);
    const auto base_pack = pack;
    std::ostringstream meta;
    meta << std::setprecision(17) << "{\"event\":\"metadata\",\"schema\":2,\"backend\":\"pure_cudnn_direct\""
         << ",\"cudnn_runtime\":" << cudnn_version << ",\"cudnn_headers\":" << CUDNN_VERSION
         << ",\"cuda_headers\":" << CUDART_VERSION
         << ",\"cuda_runtime\":" << runtime_version << ",\"cuda_driver\":" << driver_version
         << ",\"requested_implementation\":" << quote(c.implementation)
         << ",\"resolved_implementation\":" << resolved_implementation.dump()
         << ",\"device\":" << quote(properties.name) << ",\"sm_major\":" << properties.major
         << ",\"sm_minor\":" << properties.minor << ",\"frontend_version\":" << CUDNN_FRONTEND_VERSION
         << ",\"plan\":" << quote(plan_name) << ",\"selected_plan_index\":" << selected_index
         << ",\"plan_description\":" << quote(graph.selected(selected_index).describe()) << ",\"numeric_notes\":[";
    bool sep = false;
    for (auto note : graph.selected(selected_index).getAllNumericNotes()) {
      if (sep) meta << ','; meta << static_cast<int>(note); sep = true;
    }
    std::vector<fe::BehaviorNote_t> behavior_notes;
    CHECK(graph.get_behavior_notes_for_plan_at_index(selected_index, behavior_notes));
    meta << "],\"behavior_notes\":["; sep = false;
    for (auto note : behavior_notes) { if (sep) meta << ','; meta << static_cast<int>(note); sep = true; }
    meta << "],\"workspace_bytes\":" << workspace_bytes << ",\"workspace_allocated_bytes\":" << workspace.size
         << ",\"q_dims\":[1,16,1,128],\"kv_dims\":[1,8," << c.capacity << ",128]"
         << ",\"q_strides\":[2048,128,128,1],\"kv_strides\":[" << 8*head_stride << ',' << head_stride << ",128,1]"
         << ",\"live_q\":1,\"live_kv\":259,\"input_dtype\":\"bf16_le\",\"scale\":" << scale
         << ",\"scale_f32_bits\":" << scale_bits << ",\"q_bytes\":" << dq.size
         << ",\"kv_bytes\":" << dk.size << ",\"output_bytes\":" << dout.size << ",\"stats_bytes\":" << (c.stats ? dstats.size : 0)
         << ",\"q_file\":" << quote(fs::absolute(argv[1]).string())
         << ",\"k_file\":" << quote(fs::absolute(argv[2]).string()) << ",\"v_file\":" << quote(fs::absolute(argv[3]).string())
         << ",\"q_fnv1a64\":" << quote(hex64(fnv1a(q))) << ",\"k_fnv1a64\":" << quote(hex64(fnv1a(k)))
         << ",\"v_fnv1a64\":" << quote(hex64(fnv1a(v)))
         << ",\"source_k_fnv1a64\":" << quote(hex64(fnv1a(k_source))) << ",\"source_v_fnv1a64\":" << quote(hex64(fnv1a(v_source)))
         << ",\"q_ptr\":" << quote(address(dq.p)) << ",\"k_ptr\":" << quote(address(dk.p))
         << ",\"v_ptr\":" << quote(address(dv.p)) << ",\"o_ptr\":" << quote(address(dout.p))
         << ",\"stats_ptr\":" << quote(address(dstats.p)) << ",\"workspace_ptr\":" << quote(address(workspace.p))
         << ",\"len_q_ptr\":" << quote(address(dqlen.p)) << ",\"len_kv_ptr\":" << quote(address(dkvlen.p))
         << ",\"scale_ptr\":" << quote(address(c.device_scale ? dscale.p : &scale)) << '}';
    emit(meta.str());
    std::cout << "plan=" << plan_name << " index=" << selected_index << " workspace=" << workspace_bytes
              << " cudnn=" << cudnn_version << " executions=" << count << '\n';
    std::vector<std::vector<uint8_t>> outputs, statistics;
    std::size_t mismatches = 0, stats_mismatches = 0, nonfinite_runs = 0;
    for (std::size_t iteration = 0; iteration < count; ++iteration) {
      // Same stream orders poison before cuDNN. Every execution synchronizes before any readback.
      if (c.device_sync) CHECK(cudaDeviceSynchronize());
      if (c.poison >= 0) {
        CHECK(cudaMemsetAsync(dout.p, c.poison, dout.size, session.stream));
        if (c.stats) CHECK(cudaMemsetAsync(dstats.p, c.poison, dstats.size, session.stream));
      }
      if (c.workspace_poison >= 0)
        CHECK(cudaMemsetAsync(workspace.p, c.workspace_poison, workspace.size, session.stream));
      // Frontend may insert pointers to per-call temporaries. Never reuse those inserted UIDs.
      pack = base_pack;
      CHECK(graph.execute_plan_at_index(session.handle, pack, workspace.p, selected_index));
      if (iteration == 0) {
        std::ostringstream added;
        added << "{\"event\":\"frontend_added_uids\",\"original_size\":" << base_pack.size()
              << ",\"after_size\":" << pack.size() << ",\"uids\":[";
        bool comma = false;
        for (const auto& entry : pack) if (!base_pack.count(entry.first)) {
          if (comma) added << ',';
          added << entry.first;
          comma = true;
        }
        added << "]}";
        emit(added.str());
      }
      CHECK(cudaPeekAtLastError());
      CHECK(cudaStreamSynchronize(session.stream));
      if (c.device_sync) CHECK(cudaDeviceSynchronize());
      const auto output = dout.download();
      const auto stat = c.stats ? dstats.download() : std::vector<uint8_t>{};
      const auto q_after = dq.download(), k_after = dk.download(), v_after = dv.download();
      const auto qlen_after = dqlen.download(), kvlen_after = dkvlen.download(), scale_after = dscale.download();
      uint32_t host_scale_after; std::memcpy(&host_scale_after, &scale, 4);
      const bool inputs_equal = q_after == q && k_after == k && v_after == v &&
          qlen_after == qlen_ref && kvlen_after == kvlen_ref && scale_after == scale_ref && host_scale_after == scale_bits;
      const auto output_id = save_unique(outputs, output, dir, "output", c.f32);
      const auto stat_id = c.stats ? save_unique(statistics, stat, dir, "stats", true) : 0;
      const auto difference = compare(outputs.front(), output, c.f32);
      const auto stats_difference = c.stats ? compare(statistics.front(), stat, true) : Differences{};
      const bool finite = finite_buffer(output,c.f32) && (!c.stats || finite_buffer(stat,true));
      if (difference.changed) ++mismatches;
      if (stats_difference.changed) ++stats_mismatches;
      if (!finite) ++nonfinite_runs;
      std::ostringstream row;
      row << std::setprecision(17) << "{\"event\":\"execution\",\"iteration\":" << iteration
          << ",\"output_id\":" << output_id << ",\"output_fnv1a64\":" << quote(hex64(fnv1a(output)))
          << ",\"matches_reference\":" << (difference.changed ? "false" : "true")
          << ",\"stats_id\":"; if (c.stats) row << stat_id; else row << "null";
      row << ",\"stats_fnv1a64\":"; if (c.stats) row << quote(hex64(fnv1a(stat))); else row << "null";
      row << ",\"stats_changed_elements\":" << stats_difference.changed
          << ",\"inputs_unchanged\":" << (inputs_equal ? "true" : "false")
          << ",\"all_finite\":" << (finite ? "true" : "false")
          << ",\"q_fnv1a64\":" << quote(hex64(fnv1a(q_after))) << ",\"k_fnv1a64\":" << quote(hex64(fnv1a(k_after)))
          << ",\"v_fnv1a64\":" << quote(hex64(fnv1a(v_after)))
          << ",\"len_q_fnv1a64\":" << quote(hex64(fnv1a(qlen_after)))
          << ",\"len_kv_fnv1a64\":" << quote(hex64(fnv1a(kvlen_after)))
          << ",\"scale_fnv1a64\":" << quote(hex64(fnv1a(scale_after)))
          << ",\"changed_elements\":" << difference.changed << ",\"first_diff_index\":";
      if (difference.changed) row << difference.first; else row << "null";
      row << ",\"max_abs_finite_delta\":" << difference.max_delta << '}';
      emit(row.str());
      if (!inputs_equal) {
        write_bytes(dir/"q-mutated.bin", q_after); write_bytes(dir/"k-mutated.bin", k_after); write_bytes(dir/"v-mutated.bin", v_after);
        write_bytes(dir/"len-q-mutated.bin", qlen_after); write_bytes(dir/"len-kv-mutated.bin", kvlen_after);
        write_bytes(dir/"scale-mutated.bin", scale_after);
        fail("device inputs/lengths/scale changed; invalid fixed-input experiment");
      }
    }
    if (nonfinite_runs) fail("nonfinite output invalidates a determinism comparison; execution records saved");
    const bool passed = mismatches == 0 && stats_mismatches == 0;
    std::ostringstream summary;
    summary << "{\"event\":\"final_summary\",\"completed_executions\":" << count
            << ",\"expected_executions\":" << count << ",\"comparisons\":" << count-1
            << ",\"mismatches\":" << mismatches << ",\"stats_mismatches\":" << stats_mismatches
            << ",\"unique_outputs\":" << outputs.size() << ",\"unique_stats\":" << statistics.size()
            << ",\"input_changes\":0,\"nonfinite_runs\":" << nonfinite_runs
            << ",\"all_passed\":" << (passed ? "true" : "false") << '}';
    emit(summary.str()); std::cout << summary.str() << '\n';
    log.close(); return passed ? 0 : 1;
  } catch (const std::exception& e) {
    try { emit("{\"event\":\"error\",\"message\":" + quote(e.what()) + '}'); } catch (...) {}
    throw;
  }
}
int main(int argc, char** argv) {
  try { return run(argc,argv); }
  catch (const std::exception& e) { std::cerr << "ERROR: " << e.what() << '\n'; return 2; }
}
