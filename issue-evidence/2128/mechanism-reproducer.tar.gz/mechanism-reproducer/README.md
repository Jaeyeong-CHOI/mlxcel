# Captured-operand warp-sum mechanism reproducer

This small CUDA program reproduces the **floating-point mechanism from measured operands**: changing only the order of four warp contributions changes a softmax denominator, the approximate reciprocal, and an output's BF16 rounding.

It is **not** a complete cuDNN/attention test, a cuDNN replacement, or a production fix. It embeds 48 measured FP32 partials, 12 measured online-rescaling factors and one measured numerator. It requires no model, Q/K/V files, MLX, cuDNN headers or cuDNN library. No proprietary cubin or library is included.

## Tested scope

The original helper was tested on NVIDIA GB10, `sm_121`, CUDA 13. The three fixed-order modes each produced the expected result in 1,000 samples. Captured JSONL evidence is included. This bundle was assembled and verified on CPU; it was not rebuilt or GPU-rerun during packaging.

`rcp.approx.ftz.f32` is deliberately retained. Results are expectations for that tested architecture/toolchain, not a promise that approximate reciprocal bits are identical on every GPU or compiler. Do not add `--use_fast_math` or substitute host `1.0 / denominator`.

## 1. Verify without a GPU

Requires only Python 3.9 or newer:

```sh
python3 verify.py
```

The default is CPU-only. It verifies every packaged checksum, source/operand identity, all 4,000 included records, exact expected chains and round-to-nearest-even BF16 conversion. It does not compile or launch anything.

## 2. Build and run explicitly

Requires a CUDA-capable Linux machine, CUDA 13 `nvcc`, and a GPU supporting the selected target:

```sh
sh build.sh
python3 verify.py --run-gpu ./warp-sum-replay --samples 1000 --output mechanism-run
```

The second command explicitly launches four separate, bounded modes: `0123`, `0132`, `3210`, and `natural`. Each has a 30-second process timeout. Samples are restricted to 1..10,000. The output directory must not already exist; existing evidence is never overwritten. Failure preserves the produced raw files for inspection. This tool does not manage or stop any services; arrange GPU availability separately.

Equivalent build command:

```sh
nvcc -std=c++17 -O2 -arch=sm_121 warp_sum_replay.cu -o warp-sum-replay
```

`NVCC` and `CUDA_ARCH` can select a compiler executable and target, respectively. Changing either moves beyond the tested configuration. The verifier intentionally fails on unexpected numerical chains rather than silently accepting a changed result.

Individual modes can be inspected directly:

```sh
./warp-sum-replay 10 0123
./warp-sum-replay 10 0132
./warp-sum-replay 10 3210
./warp-sum-replay 1000 natural
```

The reviewed standalone source accepts 1..100,000 samples; the supplied verification wrapper enforces the tighter bound above. One launch uses a single block of 128 threads. The reported `iteration` indexes repeated samples within that launch, not separate kernel launches.

## Expected bit chains

All hex values below describe IEEE-754 FP32 bit patterns except the final four-digit BF16 value. The fixed numerator is `3e911d66`.

| Fixed warp order | Denominator | Approximate reciprocal | FP32 product | BF16 RNE |
| --- | --- | --- | --- | --- |
| `0123` | `41eee724` | `3d09290c` | `3c1b8000` | `3c1c` |
| `0132` | `41eee725` | `3d09290b` | `3c1b7fff` | `3c1b` |
| `3210` | `41eee724` | `3d09290c` | `3c1b8000` | `3c1c` |

`3c1b8000` is exactly the BF16 midpoint, approximately `0.009490966796875`. Round-to-nearest-even chooses `3c1c`; `3c1b7fff` is immediately below that midpoint and rounds to `3c1b`. The GPU helper reports the three FP32 values. The Python verifier performs the final exact integer-based BF16 RNE conversion; it does not claim to execute a GPU BF16 store.

Natural mode uses a shared-memory CAS retry loop. Fixed-order modes use the same partials and FP32 additions with an unconditional block barrier between warp contributions. Different arrival order is permitted in natural mode but not guaranteed to occur in any finite run. The included natural-mode 1,000-sample run happened to show just the first chain. The verifier accepts one or both allowed chains in natural mode; it does not manufacture a failure when scheduling happens to be repeatable.

## Interpretation and limits

- Inputs, numerator and arithmetic choices remain fixed; only the contribution order is changed by the fixed-order control.
- Each tile combines four warp-local contributions at each of four lane positions, then applies the measured online-rescaling FMA. Three tiles are replayed. A final fixed pairwise addition gives the denominator.
- IEEE-754 FP32 addition is not associative. These captured operands are a concrete witness: two legal addition orders straddle a BF16 output threshold after approximate reciprocal and multiplication.
- A CAS retry loop prevents lost updates but does not specify the order of floating-point additions. This reproducer does not demonstrate an invalid memory access, lost update, or hardware arithmetic defect.
- The partials and scales were captured from one selected coordinate of an actual attention execution. They are not random toy data, but replaying them alone does not prove the full kernel's scheduling order or reproduce all model behavior.
- Fixed-order reproducibility is not a claim about performance or an implementation suitable for deployment. A separate full-kernel intervention and full-output comparison are needed to connect the mechanism to the complete kernel.

## Contents and provenance

- `warp_sum_replay.cu`: exact independently source-reviewed helper, SHA256 `02e3161d5a64822a04b2e9eb471b055dafa528760cb90a0c805fb1a9c0e08446`.
- `expected.json`: all 60 operand bit patterns, layout, expected chains and evidence provenance hashes.
- `source-review.json`: original CPU source-review checklist and limitations.
- `evidence/*.jsonl`: normalized, contiguous records from the existing tested helper runs; no service logs or machine paths.
- `verify.py`: offline and optional bounded runtime verification.
- `build.sh`: standalone build; no cuDNN dependency.
- `SHA256SUMS`: checksums for the packaged files, excluding the checksum file itself.

No machine paths, service configuration, credentials, executables or proprietary GPU images are required or included.
