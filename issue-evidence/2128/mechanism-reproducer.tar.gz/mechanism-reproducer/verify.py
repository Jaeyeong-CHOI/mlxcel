#!/usr/bin/env python3
"""Offline verification by default; optional bounded GPU runs of an existing binary."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

BASE = Path(__file__).resolve().parent
FIELDS = ('denominator', 'reciprocal', 'product')

def require(condition, message):
    if not condition:
        raise ValueError(message)

def bf16_rne(bits):
    value = int(bits, 16)
    require((value & 0x7f800000) != 0x7f800000, 'finite fixture required')
    return f'{((value + 0x7fff + ((value >> 16) & 1)) >> 16) & 0xffff:04x}'

def check_hashes():
    entries = (BASE / 'SHA256SUMS').read_text().splitlines()
    require(len(entries) > 0, 'empty checksums')
    for entry in entries:
        digest, name = entry.split('  ', 1)
        p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts, 'unsafe checksum name')
        require(hashlib.sha256((BASE / p).read_bytes()).hexdigest() == digest,
                f'checksum differs: {name}')
    return len(entries)

def check_records(raw, order, samples, expected):
    require(len(raw) <= samples * 200, 'output exceeds bounded record size')
    lines = raw.decode('utf-8').splitlines()
    require(len(lines) == samples, f'{order}: expected {samples} lines, got {len(lines)}')
    allowed = {tuple(c[k] for k in FIELDS): c['bf16'] for c in expected['chains']}
    fixed = expected['fixed_orders'].get(order)
    counts = Counter()
    for i, line in enumerate(lines):
        row = json.loads(line)
        require(set(row) == {'iteration', *FIELDS}, f'{order}: record fields')
        require(type(row['iteration']) is int and row['iteration'] == i,
                f'{order}: noncontiguous iteration')
        for key in FIELDS:
            require(isinstance(row[key], str) and re.fullmatch('[0-9a-f]{8}', row[key]),
                    f'{order}: invalid hex {key}')
        triple = tuple(row[k] for k in FIELDS)
        require(triple in allowed, f'{order}: unexpected chain {triple}')
        require(bf16_rne(row['product']) == allowed[triple], f'{order}: BF16 conversion')
        if fixed:
            require(triple == tuple(fixed[k] for k in FIELDS),
                    f'{order}: fixed-order result differs: {triple}')
        counts[triple] += 1
    return [dict(zip(FIELDS, chain), bf16=allowed[chain], count=count)
            for chain, count in sorted(counts.items())]

def offline():
    checked = check_hashes()
    expected = json.loads((BASE / 'expected.json').read_text())
    source = (BASE / 'warp_sum_replay.cu').read_bytes()
    require(hashlib.sha256(source).hexdigest() == expected['source_sha256'], 'source SHA')
    text = source.decode()
    for name, count in [('partials', 48), ('scales', 12)]:
        found = re.search(r'uint32_t ' + name + r'\[\d+\]=\{([^}]+)\}', text)
        require(found is not None, f'missing source {name}')
        values = re.findall(r'0x([0-9a-f]{8})U', found[1])
        require(len(values) == count and values == expected[name], f'{name} bits differ')
    require('0x' + expected['numerator_bits'] + 'U' in text, 'numerator bits differ')
    report = {'mode': 'offline', 'gpu_executed': False, 'checksummed_files': checked,
              'source_sha256': expected['source_sha256'], 'evidence': {}}
    for order, observation in expected['original_observations'].items():
        raw = (BASE / 'evidence' / f'{order}.jsonl').read_bytes()
        require(hashlib.sha256(raw).hexdigest() == observation['normalized_evidence_sha256'],
                f'{order}: evidence hash differs')
        report['evidence'][order] = check_records(raw, order, observation['samples'], expected)
    report['result'] = 'PASS'
    return expected, report

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-gpu', metavar='EXISTING_BINARY',
                        help='Explicitly run an already-built binary; omitted means CPU-only.')
    parser.add_argument('--samples', type=int, default=1000,
                        help='Samples per GPU mode, 1..10000; default 1000.')
    parser.add_argument('--output', type=Path, default=Path('mechanism-run'),
                        help='New directory for raw GPU results; must not already exist.')
    args = parser.parse_args()
    require(1 <= args.samples <= 10000, 'samples must be 1..10000')
    expected, report = offline()
    print(json.dumps(report, indent=2))
    if not args.run_gpu:
        return
    binary = Path(args.run_gpu).resolve(strict=True)
    require(binary.is_file(), 'binary must be a file')
    args.output.mkdir(parents=False, exist_ok=False)
    run = {'mode': 'gpu', 'samples_per_mode': args.samples, 'timeout_seconds_per_mode': 30,
           'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'results': {}}
    for order in ('0123', '0132', '3210', 'natural'):
        with (args.output / f'{order}.jsonl').open('xb') as out, \
             (args.output / f'{order}.stderr').open('xb') as err:
            result = subprocess.run([str(binary), str(args.samples), order],
                                    stdin=subprocess.DEVNULL, stdout=out, stderr=err, timeout=30)
        require(result.returncode == 0, f'{order}: binary exit {result.returncode}')
        raw = (args.output / f'{order}.jsonl').read_bytes()
        run['results'][order] = check_records(raw, order, args.samples, expected)
    run['result'] = 'PASS'
    (args.output / 'summary.json').write_text(json.dumps(run, indent=2) + '\n')
    print(json.dumps(run, indent=2))

if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, subprocess.TimeoutExpired) as exc:
        print(f'FAIL: {exc}', file=sys.stderr)
        raise SystemExit(1)
