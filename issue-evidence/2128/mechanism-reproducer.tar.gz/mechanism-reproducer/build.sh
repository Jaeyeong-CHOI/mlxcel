#!/bin/sh
set -eu
bundle_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
"${NVCC:-nvcc}" -std=c++17 -O2 -arch="${CUDA_ARCH:-sm_121}" \
  "$bundle_dir/warp_sum_replay.cu" -o "${1:-./warp-sum-replay}"
