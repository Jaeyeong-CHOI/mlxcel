// Minimal mechanism replay: measured48FP32partial sums, no cuDNN/MLX/model/QKV.
#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#define CK(x) do{cudaError_t e=(x);if(e!=cudaSuccess){fprintf(stderr,"%s: %s\n",#x,cudaGetErrorString(e));return 2;}}while(0)
__device__ __constant__ uint32_t partials[48]={0x3e4aceffU,0x3f077c54U,0x3f0e992bU,0x3ef3df2eU,0x3eda0d87U,0x3f5a823dU,0x3fb3bd9cU,0x3f13d334U,0x3e1e735dU,0x3f970a99U,0x3fc67775U,0x3f9c8078U,0x3e4bea0dU,0x3f3b0e84U,0x3fd48a5bU,0x40084f1aU,0x3e990d7dU,0x3f86116aU,0x3fbb4530U,0x403fbecfU,0x3f31a7ddU,0x3f9e65b9U,0x3faf84b5U,0x4053b549U,0x3f4cc17cU,0x3fb7a72bU,0x3fad1814U,0x40415ebaU,0x3f2bed9dU,0x3f881bc0U,0x3f8dbb56U,0x4042115cU,0x3eabb27cU,0x00000000U,0x00000000U,0x00000000U,0x3ef98983U,0x00000000U,0x00000000U,0x00000000U,0x00000000U,0x00000000U,0x00000000U,0x00000000U,0x00000000U,0x00000000U,0x00000000U,0x00000000U};
__device__ __constant__ uint32_t scales[12]={0x00000000U,0x00000000U,0x00000000U,0x00000000U,0x3e99181bU,0x3e99181bU,0x3e99181bU,0x3e99181bU,0x3f800000U,0x3f800000U,0x3f800000U,0x3f800000U};
__device__ float add(float a,float b){float r;asm volatile("add.rn.f32 %0,%1,%2;":"=f"(r):"f"(a),"f"(b));return r;}
__device__ float partial_fma(float a,float b,float c){float r;asm volatile("fma.rn.ftz.f32 %0,%1,%2,%3;":"=f"(r):"f"(a),"f"(b),"f"(c));return r;}
__device__ void atomic_sum(volatile uint32_t* p,float x){uint32_t old=*p,assumed;do{assumed=old;uint32_t sum=__float_as_uint(add(__uint_as_float(assumed),x));old=atomicCAS((uint32_t*)p,assumed,sum);}while(old!=assumed);}
__global__ void replay(uint32_t*out,int n,int order){
 __shared__ volatile uint32_t sums[4];__shared__ float den[4];
 int lane=threadIdx.x&31,warp=threadIdx.x>>5;
 for(int sample=0;sample<n;++sample){
  if(threadIdx.x<4)den[lane]=0;__syncthreads();
  for(int t=0;t<3;++t){
   if(threadIdx.x<4)sums[lane]=0;__syncthreads();
   float x=lane<4?__uint_as_float(partials[t*16+lane*4+warp]):0;
   if(order<0){if(lane<4)atomic_sum(&sums[lane],x);__syncthreads();}
   else{for(int rank=0;rank<4;++rank){int selected=(order>>(rank*4))&15;if(lane<4&&warp==selected)sums[lane]=__float_as_uint(add(__uint_as_float(sums[lane]),x));__syncthreads();}}
   if(threadIdx.x<4)den[lane]=partial_fma(den[lane],__uint_as_float(scales[t*4+lane]),__uint_as_float(sums[lane]));__syncthreads();
  }
  if(threadIdx.x==0){float d=add(add(den[0],den[1]),add(den[2],den[3])),rcp,y;asm volatile("rcp.approx.ftz.f32 %0,%1;":"=f"(rcp):"f"(d));float num=__uint_as_float(0x3e911d66U);asm volatile("mul.rn.ftz.f32 %0,%1,%2;":"=f"(y):"f"(num),"f"(rcp));out[sample*3]=__float_as_uint(d);out[sample*3+1]=__float_as_uint(rcp);out[sample*3+2]=__float_as_uint(y);}
  __syncthreads();
 }
}
int main(int argc,char**argv){if(argc!=3)return 2;int n=atoi(argv[1]);if(n<1||n>100000)return 2;int order=-1;if(argv[2][0]!='n'){if(strlen(argv[2])!=4)return 2;order=0;int mask=0;for(int i=0;i<4;++i){int d=argv[2][i]-'0';if(d<0||d>3||(mask&(1<<d)))return 2;mask|=1<<d;order|=d<<(4*i);}}
 uint32_t*d;CK(cudaMalloc(&d,n*12));replay<<<1,128>>>(d,n,order);CK(cudaGetLastError());CK(cudaDeviceSynchronize());std::vector<uint32_t>out(n*3);CK(cudaMemcpy(out.data(),d,n*12,cudaMemcpyDeviceToHost));for(int i=0;i<n;++i)printf("{\"iteration\":%d,\"denominator\":\"%08x\",\"reciprocal\":\"%08x\",\"product\":\"%08x\"}\n",i,out[3*i],out[3*i+1],out[3*i+2]);CK(cudaFree(d));return 0;}
